package com.example.iptvplayer.data

import java.security.MessageDigest
import java.util.UUID

data class ParentalState(
    val hasPin: Boolean = false,
    val autoAdult: Boolean = true,
    val lockedGroups: Set<String> = emptySet(),
    /** Déverrouillé pour la session en cours (se reverrouille quand l'app quitte l'écran). */
    val unlocked: Boolean = false
)

object Parental {
    private val adult = Regex(
        """(?i)(\bxxx\b|\badults?\b|\badultes?\b|\bporn\w*|\b[eé]rotic\w*|\b[eé]rotique\w*|18\+|\+18|\bsex\b)"""
    )

    fun matchesAdult(s: String) = adult.containsMatchIn(s)
    fun newSalt(): String = UUID.randomUUID().toString()
    fun hash(salt: String, pin: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }

    /** Les contenus verrouillés sont masqués tant que c'est vrai. */
    fun restricted(p: ParentalState) = p.hasPin && !p.unlocked

    fun isGroupLocked(group: String, p: ParentalState) =
        group in p.lockedGroups || (p.autoAdult && matchesAdult(group))

    fun isTextLocked(category: String, name: String, p: ParentalState) =
        isGroupLocked(category, p) || (p.autoAdult && matchesAdult(name))

    fun isChannelLocked(c: Channel, p: ParentalState) =
        isGroupLocked(c.groupName, p) || (p.autoAdult && matchesAdult(c.name))
}
