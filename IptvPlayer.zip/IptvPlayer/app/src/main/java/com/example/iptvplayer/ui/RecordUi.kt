package com.example.iptvplayer.ui

import android.text.format.Formatter
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.iptvplayer.data.Programme
import com.example.iptvplayer.record.Recorder
import java.io.File
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Choix de la durée d'un enregistrement immédiat, ou programmation à une heure précise. */
@Composable
fun RecordDialog(
    channelName: String, now: Programme?,
    onStart: (durationSec: Long) -> Unit,
    onSchedule: ((startAt: Long, endAt: Long) -> Unit)? = null,
    onDismiss: () -> Unit
) {
    var picking by remember { mutableStateOf(false) }
    if (picking && onSchedule != null) {
        ScheduleRecordDialog(
            channelName,
            onConfirm = { s, e -> onSchedule(s, e); onDismiss() },
            onDismiss = { picking = false }
        )
        return
    }
    val remainingMin = now?.let { ((it.stop - System.currentTimeMillis()) / 60_000).toInt() } ?: 0
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Enregistrer $channelName") },
        text = {
            Column {
                if (now != null && remainingMin > 0) {
                    TextButton(onClick = { onStart(remainingMin * 60L + 60); onDismiss() }) {
                        Text("Jusqu'à la fin de « ${now.title} » ($remainingMin min)", maxLines = 2)
                    }
                }
                TextButton(onClick = { onStart(30 * 60L); onDismiss() }) { Text("30 minutes") }
                TextButton(onClick = { onStart(60 * 60L); onDismiss() }) { Text("1 heure") }
                TextButton(onClick = { onStart(2 * 60 * 60L); onDismiss() }) { Text("2 heures") }
                TextButton(onClick = { onStart(0L); onDismiss() }) { Text("Jusqu'à l'arrêt manuel") }
                if (onSchedule != null) {
                    HorizontalDivider(Modifier.padding(vertical = 4.dp))
                    TextButton(onClick = { picking = true }) {
                        Icon(Icons.Default.Alarm, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Programmer à une heure précise…")
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

/** Jour + heure + durée. Les boutons −/+ restent utilisables à la télécommande. */
@Composable
fun ScheduleRecordDialog(channelName: String, onConfirm: (startAt: Long, endAt: Long) -> Unit, onDismiss: () -> Unit) {
    val initial = remember {
        Calendar.getInstance().apply {
            add(Calendar.MINUTE, 10); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            val m = get(Calendar.MINUTE); add(Calendar.MINUTE, ((m + 4) / 5) * 5 - m)   // prochain multiple de 5 min
        }
    }
    val today = remember { Calendar.getInstance().get(Calendar.DAY_OF_YEAR) }
    var day by remember { mutableIntStateOf(if (initial.get(Calendar.DAY_OF_YEAR) != today) 1 else 0) }
    var hour by remember { mutableIntStateOf(initial.get(Calendar.HOUR_OF_DAY)) }
    var minute by remember { mutableIntStateOf(initial.get(Calendar.MINUTE)) }
    var durMin by remember { mutableIntStateOf(60) }

    val start = Calendar.getInstance().apply {
        add(Calendar.DAY_OF_YEAR, day)
        set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    val end = start + durMin * 60_000L
    val valid = start > System.currentTimeMillis() + 15_000
    val dayFmt = remember { SimpleDateFormat("EEE d MMM", Locale.getDefault()) }
    val hm = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Programmer : $channelName", maxLines = 2) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Jour", style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items((0..6).toList()) { d ->
                        val label = when (d) {
                            0 -> "Aujourd'hui"; 1 -> "Demain"
                            else -> dayFmt.format(Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, d) }.time)
                        }
                        FilterChip(selected = day == d, onClick = { day = d }, label = { Text(label) })
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Stepper("Heure", "%02d".format(hour), { hour = (hour + 23) % 24 }, { hour = (hour + 1) % 24 })
                    Stepper("Minute", "%02d".format(minute), { minute = (minute + 55) % 60 }, { minute = (minute + 5) % 60 })
                }
                Text("Durée", style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf(30, 60, 90, 120, 180)) { m ->
                        FilterChip(
                            selected = durMin == m, onClick = { durMin = m },
                            label = { Text(if (m < 60) "$m min" else if (m % 60 == 0) "${m / 60} h" else "${m / 60} h ${m % 60}") }
                        )
                    }
                }
                Text(
                    if (valid) "${dayFmt.format(Date(start))} · ${hm.format(Date(start))} → ${hm.format(Date(end))}"
                    else "Cette heure est déjà passée.",
                    color = if (valid) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
            }
        },
        confirmButton = { TextButton(enabled = valid, onClick = { onConfirm(start, end) }) { Text("Programmer") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
private fun Stepper(label: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelLarge)
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilledTonalIconButton(onClick = onMinus) { Icon(Icons.Default.Remove, "Moins") }
            Text(value, style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center, modifier = Modifier.widthIn(min = 56.dp))
            FilledTonalIconButton(onClick = onPlus) { Icon(Icons.Default.Add, "Plus") }
        }
    }
}

/** En cours (arrêt), programmés (annulation) et fichiers terminés (lecture / suppression). */
@Composable
fun RecordingsDialog(vm: MainViewModel, onPlayFile: (File) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val active by vm.activeRecordings.collectAsState()
    val scheduled by vm.scheduled.collectAsState()
    val clock by vm.clock.collectAsState()
    var files by remember { mutableStateOf<List<File>>(emptyList()) }
    LaunchedEffect(active.size) {
        files = Recorder.files(ctx).filter { f -> active.values.none { it.fileName == f.name } }
    }
    val df = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }
    val slot = remember { SimpleDateFormat("EEE d MMM HH:mm", Locale.getDefault()) }
    val hm = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Enregistrements") },
        text = {
            if (active.isEmpty() && scheduled.isEmpty() && files.isEmpty()) Text("Aucun enregistrement.")
            else LazyColumn(Modifier.heightIn(max = 400.dp)) {
                items(active.values.toList()) { r ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("● ${r.channel}", color = Color.Red, maxLines = 1)
                            val min = ((clock - r.startedAt) / 60_000).coerceAtLeast(0)
                            Text("${Formatter.formatShortFileSize(ctx, r.bytes)} · $min min", style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { vm.stopRecording(r.id) }) { Text("Arrêter") }
                    }
                }
                items(scheduled, key = { "s${it.id}" }) { s ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Alarm, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.channelName, maxLines = 1)
                            Text(
                                "${slot.format(Date(s.startAt))} → ${hm.format(Date(s.endAt))}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        IconButton(onClick = { vm.cancelScheduled(s) }) { Icon(Icons.Default.Close, "Annuler la programmation") }
                    }
                }
                items(files, key = { it.name }) { f ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(f.name.removeSuffix(".ts"), maxLines = 1)
                            Text(
                                "${Formatter.formatShortFileSize(ctx, f.length())} · ${df.format(Date(f.lastModified()))}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        IconButton(onClick = { onPlayFile(f) }) { Icon(Icons.Default.PlayArrow, "Lire") }
                        IconButton(onClick = { f.delete(); files = files.filterNot { it == f } }) { Icon(Icons.Default.Delete, "Supprimer") }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}
