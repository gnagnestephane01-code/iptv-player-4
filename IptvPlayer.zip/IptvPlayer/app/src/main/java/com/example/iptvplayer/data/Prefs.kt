package com.example.iptvplayer.data

import android.content.Context

/** Réglages et contrôle parental (SharedPreferences ; le PIN est stocké haché avec un sel). */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("iptv", Context.MODE_PRIVATE)
    private fun str(k: String) = sp.getString(k, "") ?: ""
    private fun putStr(k: String, v: String) = sp.edit().putString(k, v).apply()

    var pinSalt: String get() = str("pin_salt"); set(v) = putStr("pin_salt", v)
    var pinHash: String get() = str("pin_hash"); set(v) = putStr("pin_hash", v)
    var autoAdult: Boolean
        get() = sp.getBoolean("auto_adult", true)
        set(v) = sp.edit().putBoolean("auto_adult", v).apply()
    /** Propose (puis lance) l'épisode suivant en fin d'épisode. */
    var autoNext: Boolean
        get() = sp.getBoolean("auto_next", true)
        set(v) = sp.edit().putBoolean("auto_next", v).apply()
    var backgroundPlay: Boolean
        get() = sp.getBoolean("bg_play", true)
        set(v) = sp.edit().putBoolean("bg_play", v).apply()
    /** Hauteur vidéo max choisie (0 = auto). */
    var maxHeight: Int
        get() = sp.getInt("max_height", 0)
        set(v) = sp.edit().putInt("max_height", v).apply()
    var lockedGroups: Set<String>
        get() = (sp.getStringSet("locked_groups", emptySet()) ?: emptySet()).toSet()
        set(v) = sp.edit().putStringSet("locked_groups", v.toSet()).apply()
}
