package com.example.iptvplayer.ui

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.TextButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import android.app.UiModeManager
import android.content.ComponentName
import android.content.Context
import android.content.res.Configuration
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.media3.cast.CastPlayer
import androidx.media3.cast.SessionAvailabilityListener
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import androidx.mediarouter.app.MediaRouteButton
import com.example.iptvplayer.PlaybackService
import com.example.iptvplayer.data.Channel
import com.example.iptvplayer.data.WatchProgress
import com.example.iptvplayer.data.epgKey
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastContext
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Épisode proposé à la fin de l'épisode en cours. */
class NextEpisode(val vod: PlaySource.Vod, val label: String, val title: String, val image: String)

/** Infos pour reprendre un film ou un épisode (kind = "movie" | "episode"). */
data class ResumeInfo(
    val kind: String, val baseTitle: String, val subtitle: String, val image: String,
    val refId: Long, val season: Int, val episode: Int, val category: String, val startMs: Long
)

fun WatchProgress.toVod() = PlaySource.Vod(
    if (subtitle.isEmpty()) title else "$title · $subtitle", url,
    ResumeInfo(kind, title, subtitle, image, refId, season, episode, category, positionMs)
)

internal fun fmtTime(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

sealed class PlaySource {
    /** Zapping dans une liste de chaînes. */
    class Live(val channels: List<Channel>, val index: Int) : PlaySource()
    /** Replay ou enregistrement : lecture avec avance/retour. */
    class Vod(val title: String, val url: String, val resume: ResumeInfo? = null) : PlaySource()
}

private fun videoHeights(t: Tracks): List<Int> =
    t.groups.filter { it.type == C.TRACK_TYPE_VIDEO }
        .flatMap { g -> (0 until g.length).filter { g.isTrackSupported(it) }.map { g.getTrackFormat(it).height } }
        .filter { it > 0 }.distinct().sortedDescending()

private fun applyQuality(c: MediaController, height: Int) {
    val b = c.trackSelectionParameters.buildUpon()
    if (height <= 0) b.clearVideoSizeConstraints().setForceHighestSupportedBitrate(false)
    else b.setMaxVideoSize(Int.MAX_VALUE, height).setForceHighestSupportedBitrate(true)
    c.trackSelectionParameters = b.build()
}

private fun buildItem(url: String, title: String, channel: Channel?, forCast: Boolean): MediaItem {
    val meta = MediaMetadata.Builder()
        .setTitle(title)
        .setArtist(channel?.groupName?.ifEmpty { null } ?: "IPTV")
        .apply { if (!channel?.logo.isNullOrEmpty()) setArtworkUri(android.net.Uri.parse(channel!!.logo)) }
        .build()
    val b = MediaItem.Builder().setMediaId(url).setUri(url).setMediaMetadata(meta)
    val isHls = url.substringBefore('?').lowercase().endsWith(".m3u8")
    if (isHls) b.setMimeType(MimeTypes.APPLICATION_M3U8) else if (forCast) b.setMimeType("video/mp2t")
    return b.build()
}

/**
 * Le lecteur vit dans PlaybackService (lecture en arrière-plan) ; l'écran s'y connecte via un MediaController.
 * Direct : ▲▼ chaîne, ◀ enregistrer, ▶ qualité. Replay/enregistrement : ◀▶ ±15 s. OK ou tap : infos.
 */
@Composable
fun PlayerScreen(vm: MainViewModel, source: PlaySource, onExit: () -> Unit) {
    val context = LocalContext.current
    val view = LocalView.current
    val live = source as? PlaySource.Live
    var vodState by remember { mutableStateOf(source as? PlaySource.Vod) }
    val vod = vodState
    val channels = live?.channels.orEmpty()

    var index by remember { mutableIntStateOf((live?.index ?: 0).coerceIn(0, (channels.size - 1).coerceAtLeast(0))) }
    var showOverlay by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf(false) }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var casting by remember { mutableStateOf(false) }
    var heights by remember { mutableStateOf<List<Int>>(emptyList()) }
    var maxHeight by remember { mutableIntStateOf(vm.prefs.maxHeight) }
    var showQuality by remember { mutableStateOf(false) }
    var showRecord by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    val isTv = remember {
        (context.getSystemService(Context.UI_MODE_SERVICE) as UiModeManager).currentModeType ==
            Configuration.UI_MODE_TYPE_TELEVISION
    }
    // Chromecast : désactivé sur TV ou sans Google Play Services
    val castPlayer = remember {
        if (isTv) null else runCatching { CastPlayer(CastContext.getSharedInstance(context)) }.getOrNull()
    }
    val castable = castPlayer != null && vod?.url?.startsWith("file") != true

    // --- épisode suivant ---
    val autoNext by vm.autoNext.collectAsState()
    var nextEp by remember { mutableStateOf<NextEpisode?>(null) }
    var nextDismissed by remember { mutableStateOf(false) }
    var remainingMs by remember { mutableStateOf(Long.MAX_VALUE) }
    val nextFocus = remember { FocusRequester() }

    // --- reprise : mémorise la position (films et épisodes seulement) ---
    fun saveNow() {
        val r = vod?.resume ?: return
        val c = controller ?: return
        val dur = c.duration
        if (dur <= 0 || dur == C.TIME_UNSET) return
        vm.saveProgress(vod.url, r, c.currentPosition, dur)
    }

    fun playNext() {
        val n = nextEp ?: return
        saveNow()
        nextEp = null
        vodState = n.vod
        showOverlay = true
    }

    // --- connexion au service de lecture ---
    DisposableEffect(Unit) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            try { controller = future.get() } catch (e: Exception) { error = true }
        }, ContextCompat.getMainExecutor(context))
        view.keepScreenOn = true
        onDispose {
            view.keepScreenOn = false
            controller = null
            MediaController.releaseFuture(future)
        }
    }

    DisposableEffect(castPlayer) {
        castPlayer?.setSessionAvailabilityListener(object : SessionAvailabilityListener {
            override fun onCastSessionAvailable() { casting = true }
            override fun onCastSessionUnavailable() { casting = false }
        })
        casting = castPlayer?.isCastSessionAvailable == true
        onDispose {
            castPlayer?.setSessionAvailabilityListener(null)
            castPlayer?.release()
        }
    }

    BackHandler {
        saveNow()
        controller?.run { stop(); clearMediaItems() }
        castPlayer?.stop()
        onExit()
    }

    DisposableEffect(controller, vod?.url) {
        val c = controller
        val l = object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) { error = true }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) error = false
                if (state == Player.STATE_ENDED) {
                    saveNow()
                    if (nextEp != null && !nextDismissed) playNext()
                }
            }
            override fun onTracksChanged(tracks: Tracks) { heights = videoHeights(tracks) }
        }
        c?.addListener(l)
        c?.let { heights = videoHeights(it.currentTracks) }
        onDispose { c?.removeListener(l) }
    }

    LaunchedEffect(Unit) { focus.requestFocus() }

    val channel = channels.getOrNull(index)
    val title = vod?.title ?: channel?.name.orEmpty()
    val url = vod?.url ?: channel?.url

    LaunchedEffect(controller, index, casting, vod?.url) {
        val c = controller ?: return@LaunchedEffect
        val u = url ?: return@LaunchedEffect
        error = false
        // Reprise à la dernière position ; sinon position par défaut (bord du direct pour une chaîne)
        val resumeAt = vod?.resume?.let { r ->
            val cur = if (c.currentMediaItem?.mediaId == u) c.currentPosition else 0L
            when { cur > 0 -> cur; r.startMs > 0 -> r.startMs; else -> C.TIME_UNSET }
        } ?: C.TIME_UNSET
        if (casting && castPlayer != null && castable) {
            c.stop(); c.clearMediaItems()
            castPlayer.setMediaItem(buildItem(u, title, channel, forCast = true), resumeAt)
            castPlayer.prepare(); castPlayer.play()
        } else {
            castPlayer?.stop()
            c.setMediaItem(buildItem(u, title, channel, forCast = false), resumeAt)
            applyQuality(c, maxHeight)
            c.prepare(); c.play()
        }
    }
    LaunchedEffect(maxHeight, controller) { controller?.let { applyQuality(it, maxHeight) } }
    LaunchedEffect(controller, vod?.url) {
        while (vod?.resume != null && controller != null) { delay(5000); saveNow() }
    }
    // Épisode suivant : calculé au début de chaque épisode, proposé dans les 15 dernières secondes
    LaunchedEffect(vod?.url, autoNext) {
        nextEp = null; nextDismissed = false; remainingMs = Long.MAX_VALUE
        val r = vod?.resume
        if (autoNext && r != null && r.kind == "episode") nextEp = vm.nextEpisodeAfter(r)
    }
    LaunchedEffect(controller, vod?.url) {
        while (vod?.resume?.kind == "episode") {
            controller?.let { c ->
                val d = c.duration
                remainingMs = if (d > 0 && d != C.TIME_UNSET) d - c.currentPosition else Long.MAX_VALUE
            }
            delay(1000)
        }
    }
    val showNext = nextEp != null && !nextDismissed && !casting && remainingMs > 0 && remainingMs <= 15_000L
    LaunchedEffect(showNext) {
        delay(150)
        runCatching { if (showNext) nextFocus.requestFocus() else focus.requestFocus() }
    }
    LaunchedEffect(index, showOverlay) {
        if (showOverlay) { delay(5000); showOverlay = false }
    }

    // Arrière-plan : on coupe la vidéo (audio seul) ou on met en pause selon le réglage.
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) {
        saveNow()
        val c = controller ?: return@LifecycleEventEffect
        if (vm.prefs.backgroundPlay) {
            c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true).build()
        } else {
            c.pause()
        }
    }
    LifecycleEventEffect(Lifecycle.Event.ON_START) {
        val c = controller ?: return@LifecycleEventEffect
        c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, false).build()
    }

    val schedule by remember(channel?.epgKey) { vm.schedule(channel?.epgKey.orEmpty()) }.collectAsState(emptyList())
    val clock by vm.clock.collectAsState()
    val now = schedule.firstOrNull { it.start <= clock && it.stop > clock }
    val next = schedule.firstOrNull { it.start >= (now?.stop ?: clock) }

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .focusRequester(focus)
            .onKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onKeyEvent false
                val c = controller
                // pendant la proposition, les flèches servent à passer de « Lire » à « Annuler »
                if (showNext && (e.key == Key.DirectionLeft || e.key == Key.DirectionRight || e.key == Key.DirectionUp || e.key == Key.DirectionDown)) {
                    return@onKeyEvent false
                }
                when {
                    live != null && (e.key == Key.DirectionUp || e.key == Key.PageUp || e.key == Key.ChannelUp) -> {
                        if (index < channels.lastIndex) index++
                        showOverlay = true; true
                    }
                    live != null && (e.key == Key.DirectionDown || e.key == Key.PageDown || e.key == Key.ChannelDown) -> {
                        if (index > 0) index--
                        showOverlay = true; true
                    }
                    live != null && (e.key == Key.DirectionLeft || e.key == Key.MediaRecord) -> { showRecord = true; true }
                    live != null && (e.key == Key.DirectionRight || e.key == Key.Menu) -> { showQuality = true; true }
                    vod != null && e.key == Key.DirectionRight -> { c?.seekTo(c.currentPosition + 15_000); true }
                    vod != null && e.key == Key.DirectionLeft -> { c?.seekTo((c.currentPosition - 15_000).coerceAtLeast(0)); true }
                    e.key == Key.MediaPlayPause -> { c?.let { it.playWhenReady = !it.playWhenReady }; true }
                    else -> false
                }
            }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                showOverlay = !showOverlay
            }
    ) {
        AndroidView(
            factory = { ctx -> PlayerView(ctx) },
            update = {
                it.player = if (casting && castPlayer != null && castable) castPlayer else controller
                it.useController = vod != null
            },
            onRelease = { it.player = null },
            modifier = Modifier.fillMaxSize()
        )

        AnimatedVisibility(
            visible = showNext,
            enter = fadeIn() + slideInHorizontally { it / 2 }, exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 24.dp, bottom = 150.dp)
        ) {
            nextEp?.let { n ->
                NextEpisodeCard(n, ((remainingMs + 999) / 1000).toInt(), nextFocus, onPlay = { playNext() }, onCancel = { nextDismissed = true })
            }
        }

        if (error) {
            Text(
                "Flux indisponible", color = Color.White,
                modifier = Modifier.align(Alignment.Center).background(Color(0xCC000000)).padding(16.dp)
            )
        }

        // --- boutons (tactile) : enregistrer, qualité, Chromecast ---
        AnimatedVisibility(visible = showOverlay, modifier = Modifier.align(Alignment.TopEnd)) {
            Row(Modifier.background(Color(0x99000000)).padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                if (live != null) {
                    IconButton(onClick = { showRecord = true }) {
                        Icon(Icons.Default.FiberManualRecord, "Enregistrer", tint = Color.Red)
                    }
                }
                IconButton(onClick = { showQuality = true }) { Icon(Icons.Default.Settings, "Qualité", tint = Color.White) }
                if (castable) CastButton()
            }
        }

        // --- infos programme ---
        AnimatedVisibility(visible = showOverlay, modifier = Modifier.align(Alignment.BottomCenter)) {
            Column(Modifier.fillMaxWidth().background(Color(0xCC000000)).padding(horizontal = 48.dp, vertical = 27.dp)) {
                Text(
                    if (live != null) "${index + 1}  $title" else title,
                    color = Color.White, style = MaterialTheme.typography.headlineSmall
                )
                if (live != null && now != null) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "${fmt.format(Date(now.start))} – ${fmt.format(Date(now.stop))}  ${now.title}",
                        color = Color.White, style = MaterialTheme.typography.titleMedium
                    )
                    val total = (now.stop - now.start).coerceAtLeast(1)
                    LinearProgressIndicator(
                        progress = { ((clock - now.start).toFloat() / total).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).height(4.dp)
                    )
                }
                if (live != null && next != null) {
                    Text(
                        "Ensuite · ${fmt.format(Date(next.start))}  ${next.title}",
                        color = Color(0xFFBBBBBB), style = MaterialTheme.typography.bodyMedium
                    )
                }
                if (isTv) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (live != null) "▲▼ Chaîne   ◀ Enregistrer   ▶ Qualité" else "◀ ▶ ±15 s   ⏯ Pause",
                        color = Color(0xFF888888), style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }

    if (showQuality) {
        QualityDialog(heights, maxHeight, onDismiss = { showQuality = false }) { h ->
            maxHeight = h
            vm.prefs.maxHeight = h
            showQuality = false
        }
    }
    if (showRecord && channel != null) {
        RecordDialog(
            channel.name, now,
            onStart = { sec ->
                vm.startRecording(channel, sec)
                Toast.makeText(context, "Enregistrement démarré", Toast.LENGTH_SHORT).show()
            },
            onSchedule = { s, e -> vm.scheduleRecording(channel, s, e) },
            onDismiss = { showRecord = false }
        )
    }
}

@Composable
private fun CastButton() {
    AndroidView(
        factory = { ctx -> MediaRouteButton(ctx).also { CastButtonFactory.setUpMediaRouteButton(ctx, it) } },
        modifier = Modifier.size(48.dp)
    )
}

@Composable
private fun QualityDialog(heights: List<Int>, selected: Int, onDismiss: () -> Unit, onSelect: (Int) -> Unit) {
    val options = listOf(0) + heights
    val current = if (selected in options) selected else 0
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Qualité du flux") },
        text = {
            Column {
                options.forEach { h ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onSelect(h) }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = current == h, onClick = { onSelect(h) })
                        Text(if (h == 0) "Auto" else "${h}p")
                    }
                }
                if (heights.size < 2) {
                    Text("Ce flux n'expose qu'une seule qualité.", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}

@Composable
private fun NextEpisodeCard(n: NextEpisode, seconds: Int, focus: FocusRequester, onPlay: () -> Unit, onCancel: () -> Unit) {
    Column(Modifier.width(340.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xE6101820))) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(120.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(10.dp)).background(Color(0xFF16212C))) {
                if (n.image.isNotEmpty()) {
                    AsyncImage(model = n.image, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                }
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    "ÉPISODE SUIVANT", color = MaterialTheme.colorScheme.primary,
                    fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp
                )
                Text(n.label, color = Color(0xFFCCCCCC), style = MaterialTheme.typography.labelLarge)
                Text(n.title, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 2, style = MaterialTheme.typography.bodyMedium)
            }
        }
        Row(Modifier.padding(start = 12.dp, end = 12.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = onPlay, modifier = Modifier.focusRequester(focus)) { Text("Lire (${seconds}s)") }
            Spacer(Modifier.width(8.dp))
            TextButton(onClick = onCancel) { Text("Annuler") }
        }
        LinearProgressIndicator(
            progress = { (1f - seconds / 15f).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(3.dp)
        )
    }
}
