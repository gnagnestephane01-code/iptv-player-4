package com.example.iptvplayer.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

private val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE channels ADD COLUMN catchupDays INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE channels ADD COLUMN catchupType TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE channels ADD COLUMN catchupSource TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE playlists ADD COLUMN tz TEXT NOT NULL DEFAULT ''")
    }
}

private val MIGRATION_4_5 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `movies` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`playlistId` INTEGER NOT NULL, `streamId` TEXT NOT NULL, `name` TEXT NOT NULL, `poster` TEXT NOT NULL, " +
                "`rating` REAL NOT NULL, `category` TEXT NOT NULL, `ext` TEXT NOT NULL, `year` TEXT NOT NULL, " +
                "`plot` TEXT NOT NULL, `genre` TEXT NOT NULL, `actors` TEXT NOT NULL, `director` TEXT NOT NULL, " +
                "`backdrop` TEXT NOT NULL, `duration` TEXT NOT NULL, `added` INTEGER NOT NULL, `infoLoaded` INTEGER NOT NULL)"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_movies_playlistId` ON `movies` (`playlistId`)")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `shows` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`playlistId` INTEGER NOT NULL, `seriesId` TEXT NOT NULL, `name` TEXT NOT NULL, `cover` TEXT NOT NULL, " +
                "`rating` REAL NOT NULL, `category` TEXT NOT NULL, `plot` TEXT NOT NULL, `genre` TEXT NOT NULL, " +
                "`year` TEXT NOT NULL, `actors` TEXT NOT NULL, `director` TEXT NOT NULL, `backdrop` TEXT NOT NULL, " +
                "`added` INTEGER NOT NULL)"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_shows_playlistId` ON `shows` (`playlistId`)")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `scheduled_recordings` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "`channelName` TEXT NOT NULL, `url` TEXT NOT NULL, `startAt` INTEGER NOT NULL, `endAt` INTEGER NOT NULL)"
        )
    }
}

private val MIGRATION_5_6 = object : Migration(5, 6) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `watch_progress` (`url` TEXT NOT NULL, `kind` TEXT NOT NULL, `title` TEXT NOT NULL, " +
                "`subtitle` TEXT NOT NULL, `image` TEXT NOT NULL, `refId` INTEGER NOT NULL, `season` INTEGER NOT NULL, " +
                "`episode` INTEGER NOT NULL, `category` TEXT NOT NULL, `positionMs` INTEGER NOT NULL, " +
                "`durationMs` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, `finished` INTEGER NOT NULL, PRIMARY KEY(`url`))"
        )
    }
}

@Database(
    entities = [Channel::class, Programme::class, Playlist::class, Movie::class, Show::class, ScheduledRecording::class, WatchProgress::class],
    version = 6, exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun channelDao(): ChannelDao
    abstract fun epgDao(): EpgDao
    abstract fun playlistDao(): PlaylistDao
    abstract fun catalogDao(): CatalogDao
    abstract fun scheduledDao(): ScheduledDao
    abstract fun progressDao(): ProgressDao

    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, AppDatabase::class.java, "iptv.db"
            ).addMigrations(MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6).fallbackToDestructiveMigration().build().also { instance = it }
        }
    }
}
