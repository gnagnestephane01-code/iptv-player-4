package com.example.iptvplayer

import android.Manifest
import android.app.UiModeManager
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.iptvplayer.ui.HomeScreen
import com.example.iptvplayer.ui.MainViewModel
import com.example.iptvplayer.ui.PlayerScreen
import com.example.iptvplayer.ui.PlaySource

private val TvColors = darkColorScheme(
    primary = Color(0xFF4FC3F7),
    primaryContainer = Color(0xFF004B6B),
    background = Color(0xFF0B1118),
    surface = Color(0xFF0B1118),
    surfaceVariant = Color(0xFF16212C)
)

class MainActivity : AppCompatActivity() {
    private val vm: MainViewModel by viewModels()
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val isTv = (getSystemService(UI_MODE_SERVICE) as UiModeManager).currentModeType ==
            Configuration.UI_MODE_TYPE_TELEVISION

        // Android 13+ : la notification de lecture en arrière-plan demande une autorisation
        if (!isTv && Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        setContent {
            MaterialTheme(colorScheme = TvColors) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val channels by vm.channels.collectAsState()
                    var source by remember { mutableStateOf<PlaySource?>(null) }

                    val holder = rememberSaveableStateHolder()
                    val src = source
                    if (src == null) {
                        // SaveableStateProvider : onglet, défilement et fiche ouverte sont retrouvés au retour du lecteur
                        holder.SaveableStateProvider("home") {
                            HomeScreen(
                                vm, isTv,
                                onPlay = { i -> source = PlaySource.Live(channels, i) },
                                onVod = { title, url -> source = PlaySource.Vod(title, url) },
                                onPlayVod = { source = it }
                            )
                        }
                    } else {
                        PlayerScreen(vm, src) { source = null }
                    }
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) vm.lock()   // le contrôle parental se reverrouille
    }
}
