package com.example.iptvplayer.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.iptvplayer.data.Episode
import com.example.iptvplayer.data.Movie
import com.example.iptvplayer.data.Show
import com.example.iptvplayer.data.WatchProgress
import kotlinx.coroutines.delay
import java.util.Locale

private val Night = Color(0xFF0B1118)

/** Modèle d'affichage commun aux films et aux séries. */
private data class CatalogItem(
    val key: String, val id: Long, val isMovie: Boolean, val title: String,
    val image: String, val backdrop: String, val rating: Float,
    val year: String, val genre: String, val plot: String, val infoLoaded: Boolean,
    val duration: String, val actors: String, val director: String,
    /** 0..1 : part déjà regardée (barre sur l'affiche). */
    val progress: Float = 0f
)

private fun Movie.toItem() = CatalogItem(
    "m$id", id, true, name, poster, backdrop, rating, year, genre, plot, infoLoaded, duration, actors, director
)

private fun Show.toItem() = CatalogItem(
    "s$id", id, false, name, cover, backdrop, rating, year, genre, plot, true, "", actors, director
)

// =====================================================================
//  Écrans Films / Séries
// =====================================================================

@Composable
fun MoviesScreen(vm: MainViewModel, isTv: Boolean, onPlay: (PlaySource.Vod) -> Unit) {
    val movies by vm.movies.collectAsState()
    val cats by vm.movieCategories.collectAsState()
    val cat by vm.movieCat.collectAsState()
    val cont by vm.continueWatching.collectAsState()
    val prog by vm.watchProgress.collectAsState()
    var detailId by rememberSaveable { mutableStateOf<Long?>(null) }
    val byId = remember(movies) { movies.associateBy { it.id } }
    val movieProg = remember(prog) { prog.values.filter { it.kind == "movie" && !it.finished }.associateBy { it.refId } }
    val items = remember(movies, movieProg) {
        movies.map { m -> m.toItem().copy(progress = movieProg[m.id]?.fraction() ?: 0f) }
    }

    CatalogScreen(
        vm, isTv, "Rechercher un film", items, cats, cat, { vm.movieCat.value = it },
        onEnsureInfo = { byId[it.id]?.let(vm::ensureMovieInfo) },
        onOpen = { detailId = it.id },
        cont = cont.filter { it.kind == "movie" }, onResume = { onPlay(it.toVod()) }, onRemoveProgress = vm::removeProgress
    )
    detailId?.let { MovieDetail(vm, it, isTv, onPlay) { detailId = null } }
}

@Composable
fun SeriesScreen(vm: MainViewModel, isTv: Boolean, onPlay: (PlaySource.Vod) -> Unit) {
    val shows by vm.shows.collectAsState()
    val cats by vm.showCategories.collectAsState()
    val cat by vm.showCat.collectAsState()
    val cont by vm.continueWatching.collectAsState()
    val prog by vm.watchProgress.collectAsState()
    var detailId by rememberSaveable { mutableStateOf<Long?>(null) }
    // dernier épisode entamé de chaque série
    val showProg = remember(prog) {
        prog.values.filter { it.kind == "episode" && !it.finished }.groupBy { it.refId }
            .mapValues { e -> e.value.maxByOrNull { it.updatedAt }!! }
    }
    val items = remember(shows, showProg) {
        shows.map { sh -> sh.toItem().copy(progress = showProg[sh.id]?.fraction() ?: 0f) }
    }

    CatalogScreen(
        vm, isTv, "Rechercher une série", items, cats, cat, { vm.showCat.value = it },
        onEnsureInfo = { }, onOpen = { detailId = it.id },
        cont = cont.filter { it.kind == "episode" }, onResume = { onPlay(it.toVod()) }, onRemoveProgress = vm::removeProgress
    )
    detailId?.let { ShowDetail(vm, it, isTv, onPlay) { detailId = null } }
}

@Composable
private fun CatalogScreen(
    vm: MainViewModel, isTv: Boolean, searchHint: String,
    items: List<CatalogItem>, categories: List<String>, selectedCat: String, onCat: (String) -> Unit,
    onEnsureInfo: (CatalogItem) -> Unit, onOpen: (CatalogItem) -> Unit,
    cont: List<WatchProgress>, onResume: (WatchProgress) -> Unit, onRemoveProgress: (String) -> Unit
) {
    val query by vm.catQuery.collectAsState()
    val loading by vm.loading.collectAsState()
    val hasXtream by vm.hasXtream.collectAsState()
    val total by vm.catalogTotal.collectAsState()
    val message by vm.message.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(message) { message?.let { snackbar.showSnackbar(it); vm.message.value = null } }

    // Les 6 mieux notés (clés figées : le carrousel ne saute pas quand une description arrive)
    val heroKeys = remember(items.size, query, selectedCat) {
        items.filter { it.rating > 0 }.sortedByDescending { it.rating }.take(6).ifEmpty { items.take(6) }.map { it.key }
    }
    val byKey = items.associateBy { it.key }
    val hero = heroKeys.mapNotNull { byKey[it] }
    val hPad = if (isTv) 48.dp else 12.dp

    Scaffold(snackbarHost = { SnackbarHost(snackbar) }, containerColor = Color.Transparent) { pad ->
        Column(Modifier.padding(pad)) {
            Row(Modifier.padding(horizontal = hPad), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query, onValueChange = { vm.catQuery.value = it },
                    placeholder = { Text(searchHint) }, singleLine = true, modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { vm.loadCatalog() }) { Icon(Icons.Default.Refresh, "Actualiser le catalogue") }
            }
            if (categories.isNotEmpty()) {
                LazyRow(
                    Modifier.padding(vertical = 8.dp), contentPadding = PaddingValues(horizontal = hPad),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item { FilterChip(selected = selectedCat.isEmpty(), onClick = { onCat("") }, label = { Text("Tout") }) }
                    items(categories) { c -> FilterChip(selected = selectedCat == c, onClick = { onCat(c) }, label = { Text(c) }) }
                }
            }
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())

            when {
                !hasXtream -> EmptyState(
                    "Films et séries : source Xtream Codes requise",
                    "Ajoute-en une dans l'onglet Direct (menu ⋮ → Ajouter une source).", null
                ) {}
                total == 0 && !loading -> EmptyState(
                    "Catalogue vide", "Charge les films et séries de ta source Xtream.", "Charger le catalogue"
                ) { vm.loadCatalog() }
                items.isEmpty() -> EmptyState("Aucun résultat", "Essaie une autre recherche ou catégorie.", null) {}
                else -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(if (isTv) 190.dp else 145.dp),
                    contentPadding = PaddingValues(start = hPad, end = hPad, bottom = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (query.isEmpty() && hero.size >= 3) {
                        item(key = "hero", span = { GridItemSpan(maxLineSpan) }) {
                            HeroCarousel(hero, isTv, onEnsureInfo, onOpen)
                        }
                    }
                    if (query.isEmpty() && cont.isNotEmpty()) {
                        item(key = "continue", span = { GridItemSpan(maxLineSpan) }) {
                            ContinueRow(cont, isTv, onResume, onRemoveProgress)
                        }
                    }
                    itemsIndexed(items, key = { _, it -> it.key }) { index, ci ->
                        PosterCard(ci, index, isTv, onEnsureInfo) { onOpen(ci) }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyState(title: String, hint: String, action: String?, onAction: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(Icons.Default.VideoLibrary, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary)
            Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
            Text(hint, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
            if (action != null) Button(onClick = onAction) { Text(action) }
        }
    }
}

// =====================================================================
//  Carte « vignette » animée : apparition en cascade, zoom au focus,
//  anneau de note qui se remplit, description sur 3 lignes
// =====================================================================

@Composable
private fun PosterCard(ci: CatalogItem, index: Int, isTv: Boolean, onEnsureInfo: (CatalogItem) -> Unit, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val focused by src.collectIsFocusedAsState()
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        when { pressed -> 0.96f; focused -> 1.07f; else -> 1f },
        spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium), label = "scale"
    )
    val glow by animateFloatAsState(if (focused) 1f else 0f, tween(200), label = "glow")
    val shape = RoundedCornerShape(16.dp)
    LaunchedEffect(ci.key) { onEnsureInfo(ci) }

    Column(
        Modifier
            .staggered((index % 12) * 45)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow((2 + 14 * glow).dp, shape, ambientColor = MaterialTheme.colorScheme.primary, spotColor = MaterialTheme.colorScheme.primary)
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = glow), shape)
            .clickable(interactionSource = src, indication = null, onClick = onClick)
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f)) {
            Poster(ci.image, ci.title, Modifier.fillMaxSize())
            Box(
                Modifier.fillMaxWidth().height(70.dp).align(Alignment.BottomCenter)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000))))
            )
            RatingRing(ci.rating, 42.dp, Modifier.align(Alignment.BottomStart).padding(8.dp))
            if (ci.progress > 0f) {
                LinearProgressIndicator(
                    progress = { ci.progress }, color = MaterialTheme.colorScheme.primary, trackColor = Color(0x66000000),
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(4.dp)
                )
            }
        }
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text(
                ci.title, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                fontWeight = FontWeight.Bold, style = if (isTv) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium
            )
            val meta = listOf(ci.year, ci.genre.substringBefore(',')).filter { it.isNotBlank() }.joinToString(" · ")
            Text(
                meta.ifEmpty { " " }, maxLines = 1, style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(4.dp))
            PlotText(ci, minLines = 3, maxLines = 3, style = MaterialTheme.typography.bodySmall)
        }
    }
}

/** Description : lignes « shimmer » pendant le chargement, texte ensuite. */
@Composable
private fun PlotText(ci: CatalogItem, minLines: Int, maxLines: Int, style: androidx.compose.ui.text.TextStyle, color: Color = MaterialTheme.colorScheme.onSurfaceVariant) {
    when {
        !ci.infoLoaded -> Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 3.dp)) {
            repeat(minOf(minLines, 3)) { i ->
                ShimmerBox(Modifier.fillMaxWidth(if (i == 2) 0.6f else 1f).height(8.dp).clip(RoundedCornerShape(4.dp)))
            }
        }
        ci.plot.isBlank() -> Text("Aucune description disponible.", style = style, color = color, minLines = minLines, maxLines = maxLines)
        else -> Text(
            ci.plot, style = style, color = color, minLines = minLines, maxLines = maxLines,
            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
        )
    }
}

/** Note /10 dans un anneau qui se remplit en animation (vert ≥ 7, jaune ≥ 5, rouge en dessous). */
@Composable
private fun RatingRing(rating: Float, diameter: Dp, modifier: Modifier = Modifier) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(rating) { progress.animateTo((rating / 10f).coerceIn(0f, 1f), tween(1000, 250, FastOutSlowInEasing)) }
    val color = when { rating >= 7f -> Color(0xFF21D07A); rating >= 5f -> Color(0xFFD2D531); rating > 0f -> Color(0xFFDB2360); else -> Color(0xFF6B7885) }
    Box(modifier.size(diameter).background(Color(0xE6081C22), CircleShape), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(diameter * 0.08f)) {
            val stroke = Stroke(width = this.size.minDimension * 0.11f, cap = StrokeCap.Round)
            drawArc(color.copy(alpha = 0.25f), 0f, 360f, false, style = stroke)
            drawArc(color, -90f, 360f * progress.value, false, style = stroke)
        }
        Text(
            if (rating > 0f) String.format(Locale.US, "%.1f", rating) else "–",
            color = Color.White, fontWeight = FontWeight.Bold, fontSize = (diameter.value * 0.31f).sp
        )
    }
}

// =====================================================================
//  Carrousel « À l'affiche » : fondu enchaîné + zoom lent (Ken Burns)
// =====================================================================

@Composable
private fun HeroCarousel(items: List<CatalogItem>, isTv: Boolean, onEnsureInfo: (CatalogItem) -> Unit, onOpen: (CatalogItem) -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    LaunchedEffect(items.size) {
        while (items.size > 1) { delay(6500); index = (index + 1) % items.size }
    }
    val ci = items[index.coerceIn(0, items.lastIndex)]
    LaunchedEffect(ci.key) { onEnsureInfo(ci) }

    val kb = rememberInfiniteTransition(label = "kenburns")
    val zoom by kb.animateFloat(1f, 1.15f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse), label = "zoom")
    val src = remember { MutableInteractionSource() }
    val focused by src.collectIsFocusedAsState()
    val shape = RoundedCornerShape(20.dp)

    Box(
        Modifier.fillMaxWidth().height(if (isTv) 340.dp else 235.dp)
            .clip(shape)
            .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = if (focused) 1f else 0f), shape)
            .clickable(interactionSource = src, indication = null) { onOpen(ci) }
    ) {
        Crossfade(targetState = ci.key, animationSpec = tween(900), label = "hero") { k ->
            val shown = items.firstOrNull { it.key == k } ?: ci
            Poster(
                shown.backdrop.ifEmpty { shown.image }, shown.title,
                Modifier.fillMaxSize().graphicsLayer { scaleX = zoom; scaleY = zoom },
                alignment = Alignment.TopCenter
            )
        }
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xE60B1118), Color(0x990B1118), Color.Transparent))))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC0B1118)))))

        AnimatedContent(
            targetState = ci, label = "heroText",
            transitionSpec = { (fadeIn(tween(600)) + slideInVertically(tween(600)) { it / 6 }) togetherWith fadeOut(tween(250)) },
            modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth(if (isTv) 0.55f else 0.78f).padding(16.dp)
        ) { it ->
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("À L'AFFICHE", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(it.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 2)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RatingRing(it.rating, 38.dp)
                    Text(
                        listOf(it.year, it.genre.substringBefore(',')).filter { s -> s.isNotBlank() }.joinToString(" · "),
                        color = Color(0xFFDDDDDD), style = MaterialTheme.typography.labelLarge
                    )
                }
                PlotText(it, minLines = 2, maxLines = 3, style = MaterialTheme.typography.bodySmall, color = Color(0xFFE6E6E6))
            }
        }
        Row(Modifier.align(Alignment.BottomEnd).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            items.forEachIndexed { i, _ ->
                val w by animateDpAsState(if (i == index) 22.dp else 7.dp, label = "dot")
                Box(
                    Modifier.padding(2.dp).height(7.dp).width(w).clip(CircleShape)
                        .background(if (i == index) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.4f))
                )
            }
        }
    }
}

// =====================================================================
//  Briques graphiques : affiche, shimmer, apparition en cascade
// =====================================================================

@Composable
private fun Poster(url: String, title: String, modifier: Modifier = Modifier, alignment: Alignment = Alignment.Center) {
    var loaded by remember(url) { mutableStateOf(false) }
    var failed by remember(url) { mutableStateOf(url.isBlank()) }
    val a by animateFloatAsState(if (loaded) 1f else 0f, tween(500), label = "img")
    Box(modifier) {
        if (failed) FallbackPoster(title, Modifier.fillMaxSize())
        else {
            if (!loaded) ShimmerBox(Modifier.fillMaxSize())
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current).data(url).crossfade(true).build(),
                contentDescription = title, contentScale = ContentScale.Crop, alignment = alignment,
                onSuccess = { loaded = true }, onError = { failed = true },
                modifier = Modifier.fillMaxSize().alpha(a)
            )
        }
    }
}

@Composable
private fun FallbackPoster(title: String, modifier: Modifier) {
    Box(modifier.background(Brush.verticalGradient(listOf(Color(0xFF16212C), Color(0xFF004B6B)))), contentAlignment = Alignment.Center) {
        Text(title.firstOrNull()?.uppercase() ?: "?", color = Color.White.copy(alpha = 0.55f), fontSize = 44.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ShimmerBox(modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "shimmer")
    val x by t.animateFloat(-1f, 2f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "x")
    Box(
        modifier.background(
            Brush.linearGradient(
                listOf(Color(0xFF1B2733), Color(0xFF2E3F52), Color(0xFF1B2733)),
                start = Offset(x * 500f, 0f), end = Offset(x * 500f + 350f, 250f)
            )
        )
    )
}

/** Fondu + glissement vers le haut, décalé de [delayMs]. */
@Composable
private fun Modifier.staggered(delayMs: Int): Modifier {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(delayMs.toLong()); a.animateTo(1f, tween(480, easing = FastOutSlowInEasing)) }
    return graphicsLayer {
        alpha = a.value
        translationY = (1f - a.value) * 60f
        val s = 0.92f + 0.08f * a.value
        scaleX = s; scaleY = s
    }
}

@Composable
private fun Pill(text: String) {
    Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surfaceVariant) {
        Text(text, Modifier.padding(horizontal = 12.dp, vertical = 5.dp), style = MaterialTheme.typography.labelMedium)
    }
}

// =====================================================================
//  Fiches détail (plein écran) : film puis série avec épisodes
// =====================================================================

@Composable
private fun DetailFrame(onDismiss: () -> Unit, content: @Composable () -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        var visible by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) { visible = true }
        AnimatedVisibility(
            visible,
            enter = fadeIn(tween(300)) + scaleIn(tween(380), initialScale = 0.9f) + slideInVertically(tween(380)) { it / 10 }
        ) {
            Surface(Modifier.fillMaxSize(), color = Night) { content() }
        }
    }
}

@Composable
private fun DetailHero(ci: CatalogItem, onBack: () -> Unit) {
    val kb = rememberInfiniteTransition(label = "dkb")
    val zoom by kb.animateFloat(1f, 1.12f, infiniteRepeatable(tween(10000, easing = LinearEasing), RepeatMode.Reverse), label = "dz")
    Box(Modifier.fillMaxWidth().height(300.dp)) {
        Poster(
            ci.backdrop.ifEmpty { ci.image }, ci.title,
            Modifier.fillMaxSize().graphicsLayer { scaleX = zoom; scaleY = zoom }, alignment = Alignment.TopCenter
        )
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x660B1118), Color.Transparent, Night))))
        IconButton(onClick = onBack, modifier = Modifier.padding(8.dp).background(Color(0x99000000), CircleShape)) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = Color.White)
        }
        Row(Modifier.align(Alignment.BottomStart).padding(16.dp), verticalAlignment = Alignment.Bottom) {
            Box(Modifier.width(104.dp).aspectRatio(2f / 3f).shadow(14.dp, RoundedCornerShape(12.dp)).clip(RoundedCornerShape(12.dp))) {
                Poster(ci.image, ci.title, Modifier.fillMaxSize())
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.staggered(150)) {
                Text(ci.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 3)
                Text(
                    listOf(ci.year, ci.genre).filter { it.isNotBlank() }.joinToString(" · "),
                    color = Color(0xFFCCCCCC), style = MaterialTheme.typography.labelLarge, maxLines = 2
                )
            }
        }
    }
}

@Composable
private fun DetailInfo(ci: CatalogItem) {
    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.staggered(100), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            RatingRing(ci.rating, 68.dp)
            Column {
                Text("Note des spectateurs", style = MaterialTheme.typography.labelLarge)
                Text(
                    if (ci.rating > 0f) String.format(Locale.US, "%.1f / 10", ci.rating) else "Pas encore notée",
                    style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.weight(1f))
            if (ci.duration.isNotBlank()) Pill(ci.duration)
        }
        Column(Modifier.staggered(250).animateContentSize()) {
            Text("Synopsis", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(4.dp))
            PlotText(ci, minLines = 3, maxLines = Int.MAX_VALUE, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface)
        }
        if (ci.director.isNotBlank() || ci.actors.isNotBlank()) {
            Column(Modifier.staggered(350), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (ci.director.isNotBlank()) Text("Réalisation : ${ci.director}", style = MaterialTheme.typography.bodySmall)
                if (ci.actors.isNotBlank()) Text("Avec : ${ci.actors}", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun MovieDetail(vm: MainViewModel, id: Long, isTv: Boolean, onPlay: (PlaySource.Vod) -> Unit, onDismiss: () -> Unit) {
    val prog by vm.watchProgress.collectAsState()
    val movie by remember(id) { vm.observeMovie(id) }.collectAsState(null)
    val m = movie
    LaunchedEffect(m?.id, m?.infoLoaded) { if (m != null) vm.ensureMovieInfo(m) }

    DetailFrame(onDismiss) {
        if (m == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@DetailFrame
        }
        val ci = m.toItem()
        val url = vm.movieUrl(m)
        val fr = remember { FocusRequester() }
        LaunchedEffect(Unit) { if (isTv) { delay(600); runCatching { fr.requestFocus() } } }

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 40.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item { DetailHero(ci, onDismiss) }
            item {
                val saved = url?.let { prog[it] }?.takeIf { !it.finished && it.positionMs > 10_000 }
                fun play(from: Long) {
                    url?.let { onPlay(PlaySource.Vod(ci.title, it, ResumeInfo("movie", ci.title, "", m.poster, m.id, 0, 0, m.category, from))) }
                }
                Column(
                    Modifier.padding(horizontal = 16.dp).staggered(50),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { play(saved?.positionMs ?: 0L) }, enabled = url != null,
                        modifier = Modifier.fillMaxWidth().height(52.dp).focusRequester(fr)
                    ) {
                        Icon(Icons.Default.PlayArrow, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (saved != null) "Reprendre à ${fmtTime(saved.positionMs)}" else "Lecture", fontWeight = FontWeight.Bold)
                    }
                    if (saved != null) {
                        LinearProgressIndicator(
                            progress = { saved.fraction() }, modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape)
                        )
                        OutlinedButton(onClick = { play(0L) }, Modifier.fillMaxWidth()) { Text("Depuis le début") }
                    }
                }
            }
            item { DetailInfo(ci) }
        }
    }
}

@Composable
private fun ShowDetail(vm: MainViewModel, id: Long, isTv: Boolean, onPlay: (PlaySource.Vod) -> Unit, onDismiss: () -> Unit) {
    val prog by vm.watchProgress.collectAsState()
    val show by remember(id) { vm.observeShow(id) }.collectAsState(null)
    val epsMap by vm.episodes.collectAsState()
    val loading by vm.episodesLoading.collectAsState()
    val s = show
    LaunchedEffect(s?.id) { if (s != null) vm.loadEpisodes(s) }

    DetailFrame(onDismiss) {
        if (s == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@DetailFrame
        }
        val ci = s.toItem()
        val eps = epsMap[s.id].orEmpty()
        val seasons = eps.map { it.season }.distinct().sorted()
        var chosen by rememberSaveable(id) { mutableStateOf(-1) }
        val season = if (chosen in seasons) chosen else seasons.firstOrNull() ?: 0
        val inSeason = eps.filter { it.season == season }.sortedBy { it.number }
        val lastWatched = prog.values
            .filter { it.kind == "episode" && it.refId == s.id && !it.finished && it.positionMs > 10_000 }
            .maxByOrNull { it.updatedAt }

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 40.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { DetailHero(ci, onDismiss) }
            lastWatched?.let { lw ->
                item {
                    Button(
                        onClick = { onPlay(lw.toVod()) },
                        modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(52.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Reprendre ${lw.subtitle} · ${fmtTime(lw.positionMs)}", fontWeight = FontWeight.Bold)
                    }
                }
            }
            item { DetailInfo(ci) }
            if (seasons.isNotEmpty()) {
                item {
                    LazyRow(
                        Modifier.padding(top = 8.dp), contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(seasons) { n ->
                            FilterChip(selected = season == n, onClick = { chosen = n }, label = { Text("Saison $n") })
                        }
                    }
                }
            }
            if (loading && eps.isEmpty()) {
                items(3) { ShimmerBox(Modifier.padding(horizontal = 16.dp).fillMaxWidth().height(84.dp).clip(RoundedCornerShape(14.dp))) }
            } else if (eps.isEmpty()) {
                item { Text("Aucun épisode trouvé.", Modifier.padding(16.dp)) }
            } else {
                items(inSeason.size, key = { "e$season-${inSeason[it].number}" }) { i ->
                    val ep = inSeason[i]
                    val saved = prog[ep.url]
                    val label = "S$season E${ep.number}"
                    EpisodeRow(ep, i, saved) {
                        val from = saved?.takeIf { !it.finished }?.positionMs ?: 0L
                        onPlay(
                            PlaySource.Vod(
                                "${s.name} · $label", ep.url,
                                ResumeInfo("episode", s.name, label, ep.image.ifEmpty { s.cover }, s.id, season, ep.number, s.category, from)
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EpisodeRow(ep: Episode, index: Int, saved: WatchProgress?, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val focused by src.collectIsFocusedAsState()
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.padding(horizontal = 12.dp).fillMaxWidth()
            .staggered(minOf(index, 8) * 55)
            .clip(shape)
            .background(if (focused) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            .clickable(interactionSource = src, indication = null, onClick = onClick)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(150.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(10.dp))) {
            Poster(ep.image, ep.title, Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Color(0x33000000)))
            Icon(
                Icons.Default.PlayArrow, null, tint = Color.White,
                modifier = Modifier.align(Alignment.Center).size(34.dp).background(Color(0x99000000), CircleShape).padding(4.dp)
            )
            Text(
                "E${ep.number}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopStart).padding(6.dp).background(Color(0xAA000000), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 2.dp)
            )
            if (saved != null) {
                if (saved.finished) {
                    Icon(
                        Icons.Default.Check, "Vu", tint = Color.White,
                        modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp).size(20.dp)
                            .background(Color(0xFF21D07A), CircleShape).padding(2.dp)
                    )
                } else {
                    LinearProgressIndicator(
                        progress = { saved.fraction() }, color = MaterialTheme.colorScheme.primary, trackColor = Color(0x66000000),
                        modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(4.dp)
                    )
                }
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(ep.title.ifBlank { "Épisode ${ep.number}" }, fontWeight = FontWeight.Bold, maxLines = 2, style = MaterialTheme.typography.bodyMedium)
            val meta = listOfNotNull(
                ep.rating.takeIf { it > 0f }?.let { "★ " + String.format(Locale.US, "%.1f", it) },
                ep.duration.takeIf { it.isNotBlank() }
            ).joinToString("  ·  ")
            if (meta.isNotEmpty()) Text(meta, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            if (ep.plot.isNotBlank()) Text(ep.plot, maxLines = 3, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// =====================================================================
//  « Continuer à regarder » : cartes 16:9, barre de progression animée
// =====================================================================

@Composable
private fun ContinueRow(items: List<WatchProgress>, isTv: Boolean, onResume: (WatchProgress) -> Unit, onRemove: (String) -> Unit) {
    Column {
        Text(
            "Continuer à regarder", style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp)
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(items.size, key = { items[it].url }) { i ->
                ContinueCard(items[i], i, isTv, { onResume(items[i]) }, { onRemove(items[i].url) })
            }
        }
    }
}

@Composable
private fun ContinueCard(p: WatchProgress, index: Int, isTv: Boolean, onResume: () -> Unit, onRemove: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val focused by src.collectIsFocusedAsState()
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        when { pressed -> 0.96f; focused -> 1.06f; else -> 1f },
        spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium), label = "cscale"
    )
    val glow by animateFloatAsState(if (focused) 1f else 0f, tween(200), label = "cglow")
    val frac = p.fraction()
    val bar = remember { Animatable(0f) }
    LaunchedEffect(frac) { bar.animateTo(frac, tween(900, 300, FastOutSlowInEasing)) }
    val remainMin = ((p.durationMs - p.positionMs) / 60_000).toInt().coerceAtLeast(1)
    val shape = RoundedCornerShape(16.dp)

    Box(
        Modifier.width(if (isTv) 300.dp else 230.dp).aspectRatio(16f / 9f)
            .staggered(minOf(index, 6) * 60)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow((2 + 12 * glow).dp, shape, ambientColor = MaterialTheme.colorScheme.primary, spotColor = MaterialTheme.colorScheme.primary)
            .clip(shape)
            .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = glow), shape)
            .clickable(interactionSource = src, indication = null, onClick = onResume)
    ) {
        Poster(p.image, p.title, Modifier.fillMaxSize())
        Box(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x22000000), Color(0xDD000000))))
        )
        Icon(
            Icons.Default.PlayArrow, null, tint = Color.White,
            modifier = Modifier.align(Alignment.Center).size(40.dp).background(Color(0x99000000), CircleShape).padding(6.dp)
        )
        Column(Modifier.align(Alignment.BottomStart).padding(start = 12.dp, end = 12.dp, bottom = 14.dp)) {
            Text(p.title, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, style = MaterialTheme.typography.bodyMedium)
            Text(
                listOf(p.subtitle, "$remainMin min restantes").filter { it.isNotEmpty() }.joinToString(" · "),
                color = Color(0xFFDDDDDD), style = MaterialTheme.typography.labelSmall, maxLines = 1
            )
        }
        LinearProgressIndicator(
            progress = { bar.value }, color = MaterialTheme.colorScheme.primary, trackColor = Color(0x66FFFFFF),
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(4.dp)
        )
        IconButton(
            onClick = onRemove,
            modifier = Modifier.align(Alignment.TopEnd).padding(4.dp).size(32.dp).background(Color(0x99000000), CircleShape)
        ) { Icon(Icons.Default.Close, "Retirer de la liste", tint = Color.White, modifier = Modifier.size(16.dp)) }
    }
}
