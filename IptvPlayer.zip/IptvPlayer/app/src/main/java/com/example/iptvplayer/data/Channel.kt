package com.example.iptvplayer.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "channels", indices = [Index("playlistId")])
data class Channel(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long = 0,
    val name: String,
    val url: String,
    val groupName: String = "",
    val logo: String = "",
    /** Identifiant EPG (tvg-id / epg_channel_id), en minuscules. */
    val tvgId: String = "",
    val favorite: Boolean = false,
    /** Replay : nombre de jours disponibles (0 = pas de replay). */
    val catchupDays: Int = 0,
    /** "", "default", "append" ou "shift" */
    val catchupType: String = "",
    /** Modèle d'URL de replay avec marqueurs {utc}, {Y}{m}{d}{H}{M}{S}, {dmin}… */
    val catchupSource: String = ""
)

val Channel.epgKey: String get() = if (tvgId.isEmpty()) "" else "$playlistId:$tvgId"
