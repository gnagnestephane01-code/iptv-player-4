package com.example.iptvplayer.record

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.iptvplayer.R
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Service de premier plan : enregistre en tâche de fond, même app fermée. */
class RecordingService : Service() {
    companion object {
        const val ACTION_START = "com.example.iptvplayer.REC_START"
        const val ACTION_STOP_ALL = "com.example.iptvplayer.REC_STOP_ALL"
        private const val CHANNEL_ID = "recording"
        private const val NOTIF_ID = 42
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_STOP_ALL -> { Recorder.stopAll(); if (Recorder.jobs.isEmpty()) stopSelf() }
            else -> if (Recorder.jobs.isEmpty()) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        val url = intent.getStringExtra("url")
        val name = intent.getStringExtra("name") ?: "Chaîne"
        val durationSec = intent.getLongExtra("duration", 0L)
        val id = System.currentTimeMillis()
        if (url == null) { foreground(); if (Recorder.jobs.isEmpty()) stopSelf(); return }

        val endAt = if (durationSec > 0) id + durationSec * 1000 else Long.MAX_VALUE
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date(id))
        val fileName = "${name.replace(Regex("[^A-Za-z0-9_-]+"), "_").take(40)}_$stamp.ts"
        val file = File(Recorder.dir(this), fileName)

        Recorder.active.update { it + (id to ActiveRecording(id, name, fileName, id, endAt, 0)) }
        foreground()

        var last = 0L
        val job = scope.launch {
            try {
                FileOutputStream(file).use { out ->
                    Recorder.record(url, out, endAt) { bytes ->
                        val t = System.currentTimeMillis()
                        if (t - last > 1000) {
                            last = t
                            Recorder.active.update { m -> m[id]?.let { m + (id to it.copy(bytes = bytes)) } ?: m }
                        }
                    }
                }
                Recorder.messages.tryEmit("Enregistrement terminé : $name")
            } catch (e: CancellationException) {
                Recorder.messages.tryEmit("Enregistrement arrêté : $name")
            } catch (e: Exception) {
                Recorder.messages.tryEmit("Enregistrement échoué : ${e.message ?: e.javaClass.simpleName}")
            } finally {
                Recorder.active.update { it - id }
                Recorder.jobs.remove(id)
                if (file.exists() && file.length() == 0L) file.delete()
                if (Recorder.jobs.isEmpty()) stopSelf() else foreground()
            }
        }
        Recorder.jobs[id] = job
    }

    private fun foreground() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Enregistrements", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stop = PendingIntent.getService(
            this, 0, Intent(this, RecordingService::class.java).setAction(ACTION_STOP_ALL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_rec)
            .setContentTitle("Enregistrement en cours")
            .setContentText("${Recorder.active.value.size} enregistrement(s)")
            .setOngoing(true)
            .addAction(0, "Arrêter", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(NOTIF_ID, n)
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
