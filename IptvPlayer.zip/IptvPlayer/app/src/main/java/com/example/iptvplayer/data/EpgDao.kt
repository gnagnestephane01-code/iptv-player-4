package com.example.iptvplayer.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface EpgDao {
    @Insert
    suspend fun insertAll(list: List<Programme>)

    @Query("DELETE FROM programmes WHERE playlistId = :pl")
    suspend fun deleteForPlaylist(pl: Long)

    @Query("SELECT * FROM programmes WHERE start <= :now AND stop > :now")
    fun current(now: Long): Flow<List<Programme>>

    @Query("SELECT * FROM programmes WHERE channelKey = :key AND stop > :now ORDER BY start LIMIT 400")
    fun schedule(key: String, now: Long): Flow<List<Programme>>
}
