package com.example.iptvplayer.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.iptvplayer.data.Channel
import com.example.iptvplayer.data.Parental
import com.example.iptvplayer.data.Playlist
import com.example.iptvplayer.data.Programme
import com.example.iptvplayer.data.epgKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class Dlg { IMPORT, PLAYLISTS, UNLOCK, PARENTAL, SET_PIN, SETTINGS, SCHEDULE, EPG, RECORD, RECORDINGS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChannelListScreen(vm: MainViewModel, isTv: Boolean, onPlay: (Int) -> Unit, onVod: (String, String) -> Unit) {
    val channels by vm.channels.collectAsState()
    val groups by vm.groups.collectAsState()
    val playlists by vm.playlists.collectAsState()
    val playlistFilter by vm.playlistFilter.collectAsState()
    val query by vm.query.collectAsState()
    val group by vm.group.collectAsState()
    val favOnly by vm.favOnly.collectAsState()
    val loading by vm.loading.collectAsState()
    val message by vm.message.collectAsState()
    val nowMap by vm.nowPlaying.collectAsState()
    val clock by vm.clock.collectAsState()
    val parental by vm.parental.collectAsState()
    val scheduled by vm.scheduled.collectAsState()
    val recs by vm.activeRecordings.collectAsState()

    var dialog by remember { mutableStateOf<Dlg?>(null) }
    var afterUnlock by remember { mutableStateOf<Dlg?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Channel?>(null) }
    var epgTarget by remember { mutableStateOf<Playlist?>(null) }
    var deleteTarget by remember { mutableStateOf<Playlist?>(null) }
    var recordTarget by remember { mutableStateOf<Channel?>(null) }
    fun openRecord(c: Channel?) { if (c != null) { recordTarget = c; dialog = Dlg.RECORD } }
    fun replay(c: Channel?, p: Programme) {
        if (c == null) return
        vm.replayUrl(c, p)?.let { onVod("${c.name} · ${p.title}", it) }
    }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(message) {
        message?.let { snackbar.showSnackbar(it); vm.message.value = null }
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbar) }) { pad ->
        BoxWithConstraints(Modifier.fillMaxSize().padding(pad)) {
            val wide = isTv || maxWidth >= 840.dp
            val hPad = if (isTv) 48.dp else 12.dp
            val vPad = if (isTv) 27.dp else 0.dp

            Column(Modifier.fillMaxSize().padding(horizontal = hPad, vertical = vPad)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = query, onValueChange = { vm.query.value = it },
                        placeholder = { Text("Rechercher une chaîne") },
                        singleLine = true, modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { vm.favOnly.value = !favOnly }) {
                        Icon(if (favOnly) Icons.Default.Star else Icons.Default.StarBorder, "Favoris")
                    }
                    if (recs.isNotEmpty()) {
                        IconButton(onClick = { dialog = Dlg.RECORDINGS }) {
                            Icon(Icons.Default.FiberManualRecord, "Enregistrements en cours", tint = Color.Red)
                        }
                    }
                    if (parental.hasPin) {
                        IconButton(onClick = {
                            if (parental.unlocked) { vm.lock(); vm.message.value = "Contrôle parental verrouillé" }
                            else { afterUnlock = null; dialog = Dlg.UNLOCK }
                        }) {
                            Icon(if (parental.unlocked) Icons.Default.LockOpen else Icons.Default.Lock, "Contrôle parental")
                        }
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) { Icon(Icons.Default.MoreVert, "Menu") }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(text = { Text("Ajouter une source") }, onClick = { menuOpen = false; dialog = Dlg.IMPORT })
                            DropdownMenuItem(text = { Text("Mes playlists") }, onClick = { menuOpen = false; dialog = Dlg.PLAYLISTS })
                            DropdownMenuItem(text = { Text(if (scheduled.isEmpty()) "Enregistrements" else "Enregistrements · ${scheduled.size} programmé(s)") }, onClick = { menuOpen = false; dialog = Dlg.RECORDINGS })
                            DropdownMenuItem(text = { Text("Tout actualiser") }, onClick = { menuOpen = false; vm.refreshAll() })
                            DropdownMenuItem(text = { Text("Contrôle parental") }, onClick = {
                                menuOpen = false
                                when {
                                    !parental.hasPin -> dialog = Dlg.SET_PIN
                                    !parental.unlocked -> { afterUnlock = Dlg.PARENTAL; dialog = Dlg.UNLOCK }
                                    else -> dialog = Dlg.PARENTAL
                                }
                            })
                            DropdownMenuItem(text = { Text("Réglages") }, onClick = { menuOpen = false; dialog = Dlg.SETTINGS })
                        }
                    }
                }

                if (playlists.size > 1) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                        item { FilterChip(selected = playlistFilter == 0L, onClick = { vm.selectPlaylist(0) }, label = { Text("Toutes") }) }
                        items(playlists) { p ->
                            FilterChip(selected = playlistFilter == p.id, onClick = { vm.selectPlaylist(p.id) }, label = { Text(p.name) })
                        }
                    }
                }
                if (groups.isNotEmpty()) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                        item { FilterChip(selected = group.isEmpty(), onClick = { vm.group.value = "" }, label = { Text("Tout") }) }
                        items(groups) { g ->
                            FilterChip(selected = group == g, onClick = { vm.group.value = g }, label = { Text(g) })
                        }
                    }
                }
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())

                if (channels.isEmpty() && !loading) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Aucune chaîne à afficher.")
                            Button(onClick = { dialog = Dlg.IMPORT }) { Text("Ajouter une source") }
                        }
                    }
                } else if (wide) {
                    Row(Modifier.fillMaxSize()) {
                        ChannelList(
                            channels, nowMap, clock, isTv, Modifier.weight(0.55f),
                            onPlay = onPlay, onSelect = { selected = it },
                            onLong = { selected = it; dialog = Dlg.SCHEDULE }, onFav = vm::toggleFavorite
                        )
                        Spacer(Modifier.width(16.dp))
                        Surface(
                            Modifier.weight(0.45f).fillMaxHeight(),
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            val pc = selected ?: channels.firstOrNull()
                            SchedulePane(vm, pc, isTv, nowMap[pc?.epgKey.orEmpty()], { openRecord(pc) }, { p -> replay(pc, p) })
                        }
                    }
                } else {
                    ChannelList(
                        channels, nowMap, clock, isTv, Modifier.fillMaxSize(),
                        onPlay = onPlay, onSelect = { selected = it },
                        onLong = { selected = it; dialog = Dlg.SCHEDULE }, onFav = vm::toggleFavorite
                    )
                }
            }
        }
    }

    when (dialog) {
        Dlg.IMPORT -> ImportDialog(vm) { dialog = null }
        Dlg.PLAYLISTS -> PlaylistsDialog(
            vm, playlists,
            onEpg = { epgTarget = it; dialog = Dlg.EPG },
            onDelete = { deleteTarget = it },
            onDismiss = { dialog = null }
        )
        Dlg.EPG -> epgTarget?.let { EpgDialog(vm, it) { dialog = Dlg.PLAYLISTS } } ?: run { dialog = null }
        Dlg.UNLOCK -> PinDialog(vm, onDismiss = { dialog = null }) { dialog = afterUnlock; afterUnlock = null }
        Dlg.SET_PIN -> SetPinDialog(vm, onDismiss = { dialog = null }) { dialog = Dlg.PARENTAL }
        Dlg.PARENTAL -> ParentalDialog(vm, onChangePin = { dialog = Dlg.SET_PIN }) { dialog = null }
        Dlg.SETTINGS -> SettingsDialog(vm) { dialog = null }
        Dlg.SCHEDULE -> AlertDialog(
            onDismissRequest = { dialog = null },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("Fermer") } },
            text = {
                SchedulePane(
                    vm, selected, isTv, nowMap[selected?.epgKey.orEmpty()],
                    { openRecord(selected) }, { p -> replay(selected, p); dialog = null }
                )
            }
        )
        Dlg.RECORD -> recordTarget?.let { c ->
            RecordDialog(
                c.name, nowMap[c.epgKey], onStart = { vm.startRecording(c, it) },
                onSchedule = { s, e -> vm.scheduleRecording(c, s, e) }, onDismiss = { dialog = null }
            )
        } ?: run { dialog = null }
        Dlg.RECORDINGS -> RecordingsDialog(
            vm,
            onPlayFile = { f -> dialog = null; onVod(f.name.removeSuffix(".ts"), Uri.fromFile(f).toString()) },
            onDismiss = { dialog = null }
        )
        null -> Unit
    }

    deleteTarget?.let { p ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Supprimer « ${p.name} » ?") },
            text = { Text("Ses chaînes, favoris et programmes seront supprimés.") },
            confirmButton = { TextButton(onClick = { vm.deletePlaylist(p.id); deleteTarget = null }) { Text("Supprimer") } },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Annuler") } }
        )
    }
}

@Composable
private fun ChannelList(
    channels: List<Channel>, nowMap: Map<String, Programme>, clock: Long, isTv: Boolean, modifier: Modifier,
    onPlay: (Int) -> Unit, onSelect: (Channel) -> Unit, onLong: (Channel) -> Unit, onFav: (Channel) -> Unit
) {
    LazyColumn(modifier) {
        items(channels.size, key = { channels[it].id }) { i ->
            val c = channels[i]
            ChannelRow(
                c, nowMap[c.epgKey], clock, isTv,
                onClick = { onSelect(c); onPlay(i) }, onLong = { onLong(c) },
                onFocus = { onSelect(c) }, onFav = { onFav(c) }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChannelRow(
    c: Channel, now: Programme?, clock: Long, isTv: Boolean,
    onClick: () -> Unit, onLong: () -> Unit, onFocus: () -> Unit, onFav: () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val focused by src.collectIsFocusedAsState()
    LaunchedEffect(focused) { if (focused) onFocus() }
    val bg = if (focused) MaterialTheme.colorScheme.primaryContainer else Color.Transparent

    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp)
            .clip(RoundedCornerShape(12.dp)).background(bg)
            .combinedClickable(interactionSource = src, indication = LocalIndication.current, onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 12.dp, vertical = if (isTv) 12.dp else 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val iconSize = if (isTv) 56.dp else 40.dp
        if (c.logo.isNotEmpty()) AsyncImage(model = c.logo, contentDescription = null, modifier = Modifier.size(iconSize))
        else Icon(Icons.Default.LiveTv, contentDescription = null, modifier = Modifier.size(iconSize))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                c.name, maxLines = 1,
                style = if (isTv) MaterialTheme.typography.titleLarge else MaterialTheme.typography.bodyLarge
            )
            if (now != null) {
                Text(now.title, maxLines = 1, style = MaterialTheme.typography.bodySmall)
                val total = (now.stop - now.start).coerceAtLeast(1)
                LinearProgressIndicator(
                    progress = { ((clock - now.start).toFloat() / total).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp).height(3.dp)
                )
            } else if (c.groupName.isNotEmpty()) {
                Text(c.groupName, maxLines = 1, style = MaterialTheme.typography.bodySmall)
            }
        }
        IconButton(onClick = onFav) {
            Icon(if (c.favorite) Icons.Default.Star else Icons.Default.StarBorder, "Favori")
        }
    }
}

@Composable
private fun SchedulePane(
    vm: MainViewModel, channel: Channel?, isTv: Boolean, now: Programme?,
    onRecord: () -> Unit, onReplay: (Programme) -> Unit
) {
    if (channel == null) {
        Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) { Text("Sélectionne une chaîne") }
        return
    }
    val schedule by remember(channel.epgKey) { vm.schedule(channel.epgKey) }.collectAsState(emptyList())
    val clock by vm.clock.collectAsState()
    val scheduledRecs by vm.scheduled.collectAsState()
    val fmt = remember { SimpleDateFormat("EEE HH:mm", Locale.getDefault()) }
    val endFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val listState = rememberLazyListState()
    LaunchedEffect(channel.epgKey, schedule.size) {
        val i = schedule.indexOfFirst { it.stop > clock }
        if (i > 0) listState.scrollToItem(i)
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (channel.logo.isNotEmpty()) {
                AsyncImage(model = channel.logo, contentDescription = null, modifier = Modifier.size(48.dp))
                Spacer(Modifier.width(12.dp))
            }
            Text(channel.name, style = MaterialTheme.typography.headlineSmall, maxLines = 2, modifier = Modifier.weight(1f))
            IconButton(onClick = onRecord) { Icon(Icons.Default.FiberManualRecord, "Enregistrer", tint = Color.Red) }
        }
        Spacer(Modifier.height(12.dp))
        when {
            channel.tvgId.isEmpty() -> Text("Cette chaîne n'a pas d'identifiant EPG.")
            schedule.isEmpty() -> Text("Aucun programme. Mets à jour le guide dans « Mes playlists ».")
            else -> LazyColumn(state = listState) {
                items(schedule) { p ->
                    val live = p.start <= clock && p.stop > clock
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                "${fmt.format(Date(p.start))} – ${endFmt.format(Date(p.stop))}" + if (live) "  • EN DIRECT" else "",
                                style = MaterialTheme.typography.labelLarge,
                                color = if (live) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                p.title,
                                style = if (isTv) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyLarge,
                                fontWeight = if (live) FontWeight.Bold else FontWeight.Normal
                            )
                            if (live && p.description.isNotEmpty()) {
                                Text(p.description, style = MaterialTheme.typography.bodySmall, maxLines = 5)
                            }
                        }
                        if (p.start > clock) {
                            val on = scheduledRecs.any { it.url == channel.url && kotlin.math.abs(it.startAt - (p.start - 60_000)) < 120_000 }
                            IconButton(onClick = { vm.toggleProgrammeRecording(channel, p) }) {
                                Icon(
                                    if (on) Icons.Default.AlarmOn else Icons.Default.AddAlarm,
                                    if (on) "Annuler la programmation" else "Programmer l'enregistrement",
                                    tint = if (on) Color.Red else LocalContentColor.current
                                )
                            }
                        }
                        if (vm.canReplay(channel, p)) {
                            IconButton(onClick = { onReplay(p) }) { Icon(Icons.Default.History, "Revoir") }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- dialogs : sources ----------------

@Composable
private fun ImportDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var server by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { vm.addM3uFile(name, uri); onDismiss() }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ajouter une playlist") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Nom (optionnel)") }, singleLine = true)
                TabRow(selectedTabIndex = tab) {
                    listOf("M3U (URL)", "Fichier", "Xtream").forEachIndexed { i, t ->
                        Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
                    }
                }
                when (tab) {
                    0 -> OutlinedTextField(url, { url = it }, label = { Text("URL de la playlist") }, singleLine = true)
                    1 -> Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Choisir un fichier .m3u / .m3u8") }
                    else -> {
                        OutlinedTextField(server, { server = it }, label = { Text("Serveur (http://host:port)") }, singleLine = true)
                        OutlinedTextField(user, { user = it }, label = { Text("Identifiant") }, singleLine = true)
                        OutlinedTextField(
                            pass, { pass = it }, label = { Text("Mot de passe") }, singleLine = true,
                            visualTransformation = PasswordVisualTransformation()
                        )
                    }
                }
            }
        },
        confirmButton = {
            if (tab != 1) TextButton(onClick = {
                if (tab == 0) vm.addM3uUrl(name, url) else vm.addXtream(name, server, user, pass)
                onDismiss()
            }) { Text("Ajouter") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
private fun PlaylistsDialog(
    vm: MainViewModel, playlists: List<Playlist>,
    onEpg: (Playlist) -> Unit, onDelete: (Playlist) -> Unit, onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Mes playlists") },
        text = {
            if (playlists.isEmpty()) Text("Aucune playlist.")
            else LazyColumn(Modifier.heightIn(max = 360.dp)) {
                items(playlists) { p ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, maxLines = 1, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                when (p.type) { "m3u" -> "M3U (URL)"; "xtream" -> "Xtream Codes"; else -> "Fichier local" },
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        IconButton(onClick = { vm.refreshPlaylist(p.id); onDismiss() }) { Icon(Icons.Default.Refresh, "Actualiser") }
                        IconButton(onClick = { onEpg(p) }) { Icon(Icons.Default.CalendarMonth, "Guide (EPG)") }
                        IconButton(onClick = { onDelete(p) }) { Icon(Icons.Default.Delete, "Supprimer") }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}

@Composable
private fun EpgDialog(vm: MainViewModel, playlist: Playlist, onDismiss: () -> Unit) {
    var url by remember { mutableStateOf(playlist.epgUrl) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Guide : ${playlist.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(url, { url = it }, label = { Text("URL XMLTV (.xml ou .xml.gz)") }, singleLine = true)
                Text(
                    "Rempli automatiquement avec Xtream ou si la playlist M3U contient url-tvg.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        },
        confirmButton = { TextButton(onClick = { vm.updateEpg(playlist.id, url); onDismiss() }) { Text("Mettre à jour") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

// ---------------- dialogs : contrôle parental ----------------

@Composable
private fun PinDialog(vm: MainViewModel, onDismiss: () -> Unit, onSuccess: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Code PIN") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    pin, { if (it.length <= 4 && it.all(Char::isDigit)) pin = it },
                    singleLine = true, isError = err != null,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation()
                )
                err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val r = vm.tryUnlock(pin)
                if (r == null) onSuccess() else { err = r; pin = "" }
            }) { Text("Valider") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
private fun SetPinDialog(vm: MainViewModel, onDismiss: () -> Unit, onDone: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    val kb = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Définir un code PIN") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("4 chiffres. Il protège les catégories verrouillées et ces réglages.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    pin, { if (it.length <= 4 && it.all(Char::isDigit)) pin = it }, label = { Text("Nouveau code") },
                    singleLine = true, keyboardOptions = kb, visualTransformation = PasswordVisualTransformation()
                )
                OutlinedTextField(
                    confirm, { if (it.length <= 4 && it.all(Char::isDigit)) confirm = it }, label = { Text("Confirmer") },
                    singleLine = true, keyboardOptions = kb, visualTransformation = PasswordVisualTransformation()
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = pin.length == 4 && pin == confirm,
                onClick = { if (vm.setPin(pin)) onDone() }
            ) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
private fun ParentalDialog(vm: MainViewModel, onChangePin: () -> Unit, onDismiss: () -> Unit) {
    val p by vm.parental.collectAsState()
    val allGroups by vm.allGroups.collectAsState()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Contrôle parental") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Masquer les contenus adultes")
                        Text("Détection par mots-clés (xxx, adult, 18+…)", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = p.autoAdult, onCheckedChange = vm::setAutoAdult)
                }
                Text("Catégories verrouillées", style = MaterialTheme.typography.labelLarge)
                if (allGroups.isEmpty()) Text("Aucune catégorie.", style = MaterialTheme.typography.bodySmall)
                else LazyColumn(Modifier.heightIn(max = 220.dp)) {
                    items(allGroups) { g ->
                        val auto = p.autoAdult && Parental.matchesAdult(g)
                        Row(
                            Modifier.fillMaxWidth().clickable(enabled = !auto) { vm.toggleGroupLock(g) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(checked = auto || g in p.lockedGroups, onCheckedChange = { vm.toggleGroupLock(g) }, enabled = !auto)
                            Text(g, maxLines = 1)
                        }
                    }
                }
                Row {
                    TextButton(onClick = onChangePin) { Text("Changer le PIN") }
                    TextButton(onClick = { vm.removePin(); onDismiss() }) { Text("Supprimer le PIN") }
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.lock(); onDismiss() }) { Text("Verrouiller") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}

// ---------------- dialogs : réglages ----------------

@Composable
private fun SettingsDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    val bg by vm.backgroundPlay.collectAsState()
    val next by vm.autoNext.collectAsState()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Réglages") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Lecture en arrière-plan")
                        Text(
                            "Garde le son quand l'app est réduite, avec une notification de lecture.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Switch(checked = bg, onCheckedChange = vm::setBackgroundPlay)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Épisode suivant automatique")
                        Text(
                            "Propose l'épisode suivant 15 s avant la fin et le lance à la fin.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Switch(checked = next, onCheckedChange = vm::setAutoNext)
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}
