package com.example.iptvplayer.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ChannelDao {
    @Query(
        "SELECT * FROM channels WHERE (:pl = 0 OR playlistId = :pl) AND (:group = '' OR groupName = :group) " +
            "AND (:fav = 0 OR favorite = 1) AND name LIKE '%' || :q || '%' ORDER BY playlistId, id"
    )
    fun observe(q: String, group: String, fav: Int, pl: Long): Flow<List<Channel>>

    @Query("SELECT DISTINCT groupName FROM channels WHERE groupName != '' AND (:pl = 0 OR playlistId = :pl) ORDER BY groupName")
    fun groups(pl: Long): Flow<List<String>>

    @Query("SELECT url FROM channels WHERE favorite = 1 AND playlistId = :pl")
    suspend fun favoriteUrls(pl: Long): List<String>

    @Query("SELECT DISTINCT tvgId FROM channels WHERE tvgId != '' AND playlistId = :pl")
    suspend fun tvgIds(pl: Long): List<String>

    @Query("SELECT COALESCE(MAX(catchupDays), 0) FROM channels WHERE playlistId = :pl")
    suspend fun maxCatchupDays(pl: Long): Int

    @Query("DELETE FROM channels WHERE playlistId = :pl")
    suspend fun deleteForPlaylist(pl: Long)

    @Insert
    suspend fun insertAll(list: List<Channel>)

    @Query("UPDATE channels SET favorite = :fav WHERE id = :id")
    suspend fun setFavorite(id: Long, fav: Boolean)
}
