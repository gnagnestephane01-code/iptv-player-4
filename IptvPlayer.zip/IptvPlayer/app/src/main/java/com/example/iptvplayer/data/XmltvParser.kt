package com.example.iptvplayer.data

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Locale

/** Lecture en flux d'un guide XMLTV ; ne garde que les chaînes connues et une fenêtre de temps. */
object XmltvParser {
    fun parse(input: InputStream, wanted: Set<String>, from: Long, to: Long): List<Programme> {
        val withTz = SimpleDateFormat("yyyyMMddHHmmss Z", Locale.US)
        val noTz = SimpleDateFormat("yyyyMMddHHmmss", Locale.US)
        fun time(s: String?): Long {
            if (s.isNullOrBlank()) return 0
            val t = s.trim()
            return try {
                (if (t.contains(' ')) withTz.parse(t) else noTz.parse(t))?.time ?: 0
            } catch (e: Exception) { 0 }
        }

        val out = ArrayList<Programme>()
        val parser = Xml.newPullParser()
        parser.setInput(input, null)

        var inProg = false
        var channel = ""
        var start = 0L
        var stop = 0L
        var title = ""
        var desc = ""

        var ev = parser.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "programme" -> {
                        inProg = true
                        channel = (parser.getAttributeValue(null, "channel") ?: "").trim().lowercase()
                        start = time(parser.getAttributeValue(null, "start"))
                        stop = time(parser.getAttributeValue(null, "stop"))
                        title = ""
                        desc = ""
                    }
                    "title" -> if (inProg && title.isEmpty()) title = parser.nextText().trim()
                    "desc" -> if (inProg && desc.isEmpty()) desc = parser.nextText().trim()
                }
                XmlPullParser.END_TAG -> if (parser.name == "programme") {
                    inProg = false
                    if (channel in wanted && start > 0 && stop > start && stop > from && start < to) {
                        out += Programme(
                            channelKey = channel, title = title.ifEmpty { "Sans titre" },
                            description = desc, start = start, stop = stop
                        )
                    }
                }
            }
            ev = parser.next()
        }
        return out
    }
}
