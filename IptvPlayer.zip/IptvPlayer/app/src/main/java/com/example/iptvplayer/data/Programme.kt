package com.example.iptvplayer.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "programmes", indices = [Index("channelKey"), Index("start"), Index("playlistId")])
data class Programme(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long = 0,
    /** "<playlistId>:<tvgId>" */
    val channelKey: String,
    val title: String,
    val description: String,
    val start: Long,
    val stop: Long
)
