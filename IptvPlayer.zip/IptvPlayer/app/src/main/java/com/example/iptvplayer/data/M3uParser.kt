package com.example.iptvplayer.data

data class M3uResult(val channels: List<Channel>, val epgUrl: String?)

object M3uParser {
    private val attrRegex = Regex("""([\w-]+)="([^"]*)"""")
    private val supported = setOf("default", "append", "shift")

    private fun attrs(line: String) =
        attrRegex.findAll(line).associate { it.groupValues[1].lowercase() to it.groupValues[2] }

    fun parse(text: String): M3uResult {
        val result = mutableListOf<Channel>()
        var epg: String? = null
        var hCatchup = ""
        var hDays = 0
        var hSource = ""

        var name = ""
        var group = ""
        var logo = ""
        var tvgId = ""
        var cType = ""
        var cDays = 0
        var cSource = ""
        var pending = false

        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            when {
                line.startsWith("#EXTM3U", ignoreCase = true) -> {
                    val a = attrs(line)
                    epg = (a["url-tvg"] ?: a["x-tvg-url"])
                        ?.split(',')?.firstOrNull()?.trim()?.takeIf { it.isNotEmpty() }
                    hCatchup = a["catchup"].orEmpty()
                    hDays = (a["catchup-days"] ?: a["tvg-rec"])?.toIntOrNull() ?: 0
                    hSource = a["catchup-source"].orEmpty()
                }
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    val a = attrs(line)
                    group = a["group-title"].orEmpty()
                    logo = a["tvg-logo"].orEmpty()
                    tvgId = a["tvg-id"].orEmpty().trim().lowercase()
                    cSource = a["catchup-source"] ?: hSource
                    cType = (a["catchup"] ?: hCatchup).lowercase()
                    if (cType.isEmpty() && cSource.isNotEmpty()) cType = "default"
                    cDays = (a["catchup-days"] ?: a["tvg-rec"])?.toIntOrNull() ?: hDays
                    if (cType !in supported) { cType = ""; cDays = 0 } else if (cDays <= 0) cDays = 1
                    val afterAttrs = attrRegex.findAll(line).lastOrNull()?.range?.last ?: line.indexOf(':')
                    name = line.substring(afterAttrs + 1).substringAfter(',', "").trim()
                        .ifEmpty { a["tvg-name"].orEmpty() }
                    pending = true
                }
                line.startsWith("#") -> Unit
                pending -> {
                    result += Channel(
                        name = name.ifEmpty { "Chaîne ${result.size + 1}" },
                        url = line, groupName = group, logo = logo, tvgId = tvgId,
                        catchupDays = cDays, catchupType = cType, catchupSource = cSource
                    )
                    pending = false
                }
            }
        }
        return M3uResult(result, epg)
    }
}
