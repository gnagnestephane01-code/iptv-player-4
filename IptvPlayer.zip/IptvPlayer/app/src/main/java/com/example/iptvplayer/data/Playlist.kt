package com.example.iptvplayer.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** type : "m3u" (URL), "file" (fichier local, non actualisable) ou "xtream". */
@Entity(tableName = "playlists")
data class Playlist(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String,
    val source: String = "",
    val user: String = "",
    val pass: String = "",
    val epgUrl: String = "",
    /** Fuseau du serveur Xtream (pour les URL de replay). */
    val tz: String = ""
)
