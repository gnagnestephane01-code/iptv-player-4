package com.example.iptvplayer.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** Direct / Films / Séries : sélecteur animé + contenu avec transition (le défilement de chaque onglet est conservé). */
@Composable
fun HomeScreen(
    vm: MainViewModel, isTv: Boolean,
    onPlay: (Int) -> Unit, onVod: (title: String, url: String) -> Unit,
    onPlayVod: (PlaySource.Vod) -> Unit
) {
    var tab by rememberSaveable { mutableStateOf(0) }
    val holder = rememberSaveableStateHolder()

    Column(Modifier.fillMaxSize()) {
        HomeTabs(tab, isTv) { tab = it }
        AnimatedContent(
            targetState = tab, modifier = Modifier.weight(1f), label = "tabs",
            transitionSpec = {
                val dir = if (targetState > initialState) 1 else -1
                (fadeIn(tween(320)) + slideInHorizontally(tween(320)) { it / 7 * dir }) togetherWith
                    (fadeOut(tween(200)) + slideOutHorizontally(tween(320)) { -it / 7 * dir })
            }
        ) { t ->
            holder.SaveableStateProvider(t) {
                when (t) {
                    0 -> ChannelListScreen(vm, isTv, onPlay, onVod)
                    1 -> MoviesScreen(vm, isTv, onPlayVod)
                    else -> SeriesScreen(vm, isTv, onPlayVod)
                }
            }
        }
    }
}

@Composable
private fun HomeTabs(selected: Int, isTv: Boolean, onSelect: (Int) -> Unit) {
    val tabs = listOf("Direct" to Icons.Default.LiveTv, "Films" to Icons.Default.Movie, "Séries" to Icons.Default.VideoLibrary)
    val primary = MaterialTheme.colorScheme.primary

    BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = if (isTv) 48.dp else 12.dp, vertical = 8.dp)) {
        val tabW = maxWidth / tabs.size
        val offset by animateDpAsState(tabW * selected, spring(dampingRatio = 0.75f, stiffness = Spring.StiffnessMediumLow), label = "pill")

        Box(
            Modifier.fillMaxWidth().height(if (isTv) 52.dp else 44.dp)
                .clip(RoundedCornerShape(26.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            // pastille qui glisse sous l'onglet actif
            Box(
                Modifier.offset(x = offset).width(tabW).fillMaxHeight().padding(3.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.horizontalGradient(listOf(primary, Color(0xFF81D4FA))))
            )
            Row(Modifier.fillMaxSize()) {
                tabs.forEachIndexed { i, (label, icon) ->
                    val src = remember { MutableInteractionSource() }
                    val focused by src.collectIsFocusedAsState()
                    val tint by animateColorAsState(
                        if (i == selected) Color(0xFF0B1118) else MaterialTheme.colorScheme.onSurface, tween(250), label = "tint"
                    )
                    Row(
                        Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(24.dp))
                            .border(if (focused) 2.dp else 0.dp, primary, RoundedCornerShape(24.dp))
                            .clickable(interactionSource = src, indication = null) { onSelect(i) },
                        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(label, color = tint, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}
