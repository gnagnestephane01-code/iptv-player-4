package com.example.iptvplayer.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.zip.GZIPInputStream

private fun JSONObject.str(key: String): String = if (isNull(key)) "" else optString(key)

private class XtreamData(val channels: List<Channel>, val epgUrl: String, val tz: String)

class Repository(context: Context) {
    private val app = context.applicationContext
    private val db = AppDatabase.get(app)
    private val dao = db.channelDao()
    private val epgDao = db.epgDao()
    private val plDao = db.playlistDao()
    private val catalogDao = db.catalogDao()
    private val schedDao = db.scheduledDao()
    private val progressDao = db.progressDao()
    val prefs = Prefs(app)

    val playlists = plDao.observeAll()
    fun channels(q: String, group: String, favOnly: Boolean, playlistId: Long) =
        dao.observe(q, group, if (favOnly) 1 else 0, playlistId)
    fun groups(playlistId: Long) = dao.groups(playlistId)
    fun current(now: Long) = epgDao.current(now)
    fun schedule(key: String) = epgDao.schedule(key, System.currentTimeMillis() - 7 * 86_400_000L)
    suspend fun setFavorite(id: Long, fav: Boolean) = dao.setFavorite(id, fav)

    // ---------- enregistrements programmés ----------
    val scheduled = schedDao.observe()
    val progress = progressDao.observeAll()
    suspend fun saveProgress(p: WatchProgress) = progressDao.upsert(p)
    suspend fun removeProgress(url: String) = progressDao.delete(url)
    suspend fun addScheduled(r: ScheduledRecording): Long = schedDao.insert(r)
    suspend fun removeScheduled(id: Long) = schedDao.delete(id)

    // ---------- films & séries (Xtream) ----------
    val catalogTotal = catalogDao.total()
    fun movies(q: String, cat: String, pl: Long) = catalogDao.movies(q, cat, pl)
    fun movieCategories(pl: Long) = catalogDao.movieCategories(pl)
    fun observeMovie(id: Long) = catalogDao.observeMovie(id)
    fun shows(q: String, cat: String, pl: Long) = catalogDao.shows(q, cat, pl)
    fun showCategories(pl: Long) = catalogDao.showCategories(pl)
    fun observeShow(id: Long) = catalogDao.observeShow(id)

    // ---------- réseau ----------
    private fun gunzipIfNeeded(stream: InputStream): InputStream {
        val b = BufferedInputStream(stream)
        b.mark(2)
        val m1 = b.read()
        val m2 = b.read()
        b.reset()
        return if (m1 == 0x1f && m2 == 0x8b) GZIPInputStream(b) else b
    }

    private fun open(url: String): InputStream {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 60_000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) IPTVPlayer/1.0")
        if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
        return gunzipIfNeeded(conn.inputStream)
    }

    private fun text(url: String) = open(url).bufferedReader().use { it.readText() }

    private fun hostOf(url: String) = try { URL(url).host } catch (e: Exception) { "Playlist" }

    private fun displayName(uri: Uri): String? =
        app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }

    // ---------- chargement des sources ----------
    private fun parseM3u(txt: String): M3uResult {
        val r = M3uParser.parse(txt)
        if (r.channels.isEmpty()) throw IOException("Aucune chaîne trouvée")
        return r
    }

    private fun loadXtream(server: String, user: String, pass: String): XtreamData {
        var base = server.trim().trimEnd('/')
        if (!base.startsWith("http")) base = "http://$base"
        val u = URLEncoder.encode(user.trim(), "UTF-8")
        val p = URLEncoder.encode(pass.trim(), "UTF-8")
        val api = "$base/player_api.php?username=$u&password=$p"
        val bad = "Réponse invalide : vérifie le serveur, l'identifiant et le mot de passe"

        val tz = try {
            JSONObject(text(api)).optJSONObject("server_info")?.optString("timezone").orEmpty()
        } catch (e: Exception) { "" }

        val cats = HashMap<String, String>()
        try {
            val arr = JSONArray(text("$api&action=get_live_categories"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                cats[o.str("category_id")] = o.str("category_name")
            }
        } catch (e: JSONException) { throw IOException(bad) }

        val streams = try { JSONArray(text("$api&action=get_live_streams")) } catch (e: JSONException) { throw IOException(bad) }
        val list = ArrayList<Channel>(streams.length())
        for (i in 0 until streams.length()) {
            val o = streams.getJSONObject(i)
            val sid = o.str("stream_id")
            val days = if (o.str("tv_archive") == "1") (o.str("tv_archive_duration").toIntOrNull() ?: 0) else 0
            list += Channel(
                name = o.str("name"),
                url = "$base/live/$u/$p/$sid.m3u8",
                groupName = cats[o.str("category_id")].orEmpty(),
                logo = o.str("stream_icon"),
                tvgId = o.str("epg_channel_id").trim().lowercase(),
                catchupDays = days,
                catchupType = if (days > 0) "default" else "",
                catchupSource = if (days > 0)
                    "$base/streaming/timeshift.php?username=$u&password=$p&stream=$sid&start={Y}-{m}-{d}:{H}-{M}&duration={dmin}"
                else ""
            )
        }
        if (list.isEmpty()) throw IOException("Aucune chaîne reçue")
        return XtreamData(list, "$base/xmltv.php?username=$u&password=$p", tz)
    }

    // ---------- ajout de playlists ----------
    suspend fun addM3uUrl(name: String, url: String): String = withContext(Dispatchers.IO) {
        val r = parseM3u(text(url))
        val id = plDao.insert(Playlist(name = name.ifBlank { hostOf(url) }, type = "m3u", source = url, epgUrl = r.epgUrl.orEmpty()))
        saveChannels(id, r.channels)
        "${r.channels.size} chaînes importées" + autoEpg(id)
    }

    suspend fun addM3uFile(name: String, uri: Uri): String = withContext(Dispatchers.IO) {
        val stream = app.contentResolver.openInputStream(uri) ?: throw IOException("Fichier illisible")
        val r = parseM3u(gunzipIfNeeded(stream).bufferedReader().use { it.readText() })
        val id = plDao.insert(
            Playlist(name = name.ifBlank { displayName(uri) ?: "Fichier M3U" }, type = "file", source = uri.toString(), epgUrl = r.epgUrl.orEmpty())
        )
        saveChannels(id, r.channels)
        "${r.channels.size} chaînes importées" + autoEpg(id)
    }

    suspend fun addXtream(name: String, server: String, user: String, pass: String): String = withContext(Dispatchers.IO) {
        val x = loadXtream(server, user, pass)
        val id = plDao.insert(
            Playlist(
                name = name.ifBlank { "${user.trim()}@${hostOf(if (server.startsWith("http")) server.trim() else "http://${server.trim()}")}" },
                type = "xtream", source = server.trim(), user = user.trim(), pass = pass.trim(), epgUrl = x.epgUrl, tz = x.tz
            )
        )
        saveChannels(id, x.channels)
        "${x.channels.size} chaînes importées" + autoEpg(id)
    }

    // ---------- actualisation / suppression ----------
    suspend fun refreshPlaylist(id: Long): String = withContext(Dispatchers.IO) {
        val p = plDao.get(id) ?: throw IOException("Playlist introuvable")
        when (p.type) {
            "m3u" -> {
                val r = parseM3u(text(p.source))
                saveChannels(id, r.channels)
                r.epgUrl?.let { if (it != p.epgUrl) plDao.update(p.copy(epgUrl = it)) }
                "${p.name} : ${r.channels.size} chaînes" + autoEpg(id)
            }
            "xtream" -> {
                val x = loadXtream(p.source, p.user, p.pass)
                saveChannels(id, x.channels)
                plDao.update(p.copy(epgUrl = x.epgUrl, tz = x.tz))
                "${p.name} : ${x.channels.size} chaînes" + autoEpg(id) + autoCatalog(id)
            }
            else ->
                if (p.epgUrl.isNotEmpty()) "${p.name} : guide ${updateEpg(id, p.epgUrl)} programmes"
                else throw IOException("Un fichier local ne s'actualise pas : réimporte-le")
        }
    }

    suspend fun refreshAll(): String {
        val all = plDao.all()
        if (all.isEmpty()) throw IOException("Aucune playlist")
        return all.map { p ->
            try { refreshPlaylist(p.id) } catch (e: Exception) { "${p.name} : ${e.message}" }
        }.joinToString(" | ")
    }

    suspend fun deletePlaylist(id: Long) = db.withTransaction {
        dao.deleteForPlaylist(id)
        epgDao.deleteForPlaylist(id)
        catalogDao.deleteMovies(id)
        catalogDao.deleteShows(id)
        plDao.delete(id)
    }

    // ---------- EPG ----------
    suspend fun updateEpg(playlistId: Long, url: String): Int = withContext(Dispatchers.IO) {
        val wanted = dao.tvgIds(playlistId).toSet()
        if (wanted.isEmpty()) throw IOException("Aucune chaîne n'a d'identifiant EPG (tvg-id)")
        val now = System.currentTimeMillis()
        val backMs = maxOf(2 * 3600_000L, minOf(dao.maxCatchupDays(playlistId), 7) * 86_400_000L)
        val list = open(url).use { XmltvParser.parse(it, wanted, now - backMs, now + 36 * 3600_000L) }
            .map { it.copy(playlistId = playlistId, channelKey = "$playlistId:${it.channelKey}") }
        db.withTransaction {
            epgDao.deleteForPlaylist(playlistId)
            list.chunked(1000).forEach { epgDao.insertAll(it) }
        }
        plDao.get(playlistId)?.let { if (it.epgUrl != url) plDao.update(it.copy(epgUrl = url)) }
        list.size
    }

    private suspend fun autoEpg(playlistId: Long): String {
        val url = plDao.get(playlistId)?.epgUrl.orEmpty()
        if (url.isEmpty()) return ""
        return try { " · guide : ${updateEpg(playlistId, url)} programmes" } catch (e: Exception) { " · guide : ${e.message}" }
    }

    // ---------- catalogue Xtream : outils ----------
    private fun xBase(server: String): String {
        var b = server.trim().trimEnd('/')
        if (!b.startsWith("http")) b = "http://$b"
        return b
    }
    private fun enc(s: String) = URLEncoder.encode(s.trim(), "UTF-8")
    private fun xApi(p: Playlist) = "${xBase(p.source)}/player_api.php?username=${enc(p.user)}&password=${enc(p.pass)}"

    fun movieUrl(p: Playlist, m: Movie) =
        "${xBase(p.source)}/movie/${enc(p.user)}/${enc(p.pass)}/${m.streamId}.${m.ext.ifEmpty { "mp4" }}"

    /** Note sur 10 (certains serveurs ne donnent que rating_5based). */
    private fun rating10(o: JSONObject): Float {
        val r10 = o.str("rating").replace(',', '.').toFloatOrNull() ?: 0f
        val r5 = o.str("rating_5based").replace(',', '.').toFloatOrNull() ?: 0f
        return if (r10 > 0f) r10.coerceAtMost(10f) else (r5 * 2f).coerceAtMost(10f)
    }

    private fun firstStr(o: JSONObject, key: String): String = when (val v = o.opt(key)) {
        is JSONArray -> if (v.length() > 0) v.optString(0) else ""
        is String -> v
        else -> ""
    }

    private fun categories(api: String, action: String): Map<String, String> {
        val m = HashMap<String, String>()
        try {
            val a = JSONArray(text("$api&action=$action"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                m[o.str("category_id")] = o.str("category_name")
            }
        } catch (e: JSONException) { /* catégories facultatives */ }
        return m
    }

    /** Télécharge les films et séries d'une source Xtream. Retourne un résumé. */
    suspend fun loadCatalog(playlistId: Long): String = withContext(Dispatchers.IO) {
        val p = plDao.get(playlistId) ?: throw IOException("Playlist introuvable")
        if (p.type != "xtream") throw IOException("Films et séries : source Xtream Codes requise")
        val api = xApi(p)

        val vodCats = categories(api, "get_vod_categories")
        val vodArr = try { JSONArray(text("$api&action=get_vod_streams")) } catch (e: JSONException) { JSONArray() }
        val old = catalogDao.loadedMovies(playlistId).associateBy { it.streamId }   // garde les descriptions déjà chargées
        val movies = ArrayList<Movie>(vodArr.length())
        for (i in 0 until vodArr.length()) {
            val o = vodArr.getJSONObject(i)
            val plot = o.str("plot")
            val m = Movie(
                playlistId = playlistId, streamId = o.str("stream_id"), name = o.str("name"),
                poster = o.str("stream_icon"), rating = rating10(o),
                category = vodCats[o.str("category_id")].orEmpty(),
                ext = o.str("container_extension").ifEmpty { "mp4" },
                added = o.str("added").toLongOrNull() ?: 0L,
                plot = plot, genre = o.str("genre"),
                year = o.str("year").ifEmpty { o.str("releasedate").take(4) },
                infoLoaded = plot.isNotEmpty()
            )
            movies += old[m.streamId]?.let {
                m.copy(plot = it.plot, genre = it.genre, actors = it.actors, director = it.director,
                    backdrop = it.backdrop, duration = it.duration, year = it.year.ifEmpty { m.year },
                    rating = if (m.rating > 0f) m.rating else it.rating, infoLoaded = true)
            } ?: m
        }

        val serCats = categories(api, "get_series_categories")
        val serArr = try { JSONArray(text("$api&action=get_series")) } catch (e: JSONException) { JSONArray() }
        val shows = ArrayList<Show>(serArr.length())
        for (i in 0 until serArr.length()) {
            val o = serArr.getJSONObject(i)
            shows += Show(
                playlistId = playlistId, seriesId = o.str("series_id"), name = o.str("name"),
                cover = o.str("cover"), rating = rating10(o),
                category = serCats[o.str("category_id")].orEmpty(),
                plot = o.str("plot"), genre = o.str("genre"),
                year = o.str("releaseDate").ifEmpty { o.str("release_date") }.ifEmpty { o.str("releasedate") }.take(4),
                actors = o.str("cast"), director = o.str("director"),
                backdrop = firstStr(o, "backdrop_path"),
                added = o.str("last_modified").toLongOrNull() ?: 0L
            )
        }
        if (movies.isEmpty() && shows.isEmpty()) throw IOException("Aucun film ni série sur ce serveur")

        db.withTransaction {
            catalogDao.deleteMovies(playlistId)
            catalogDao.deleteShows(playlistId)
            movies.chunked(2000).forEach { catalogDao.insertMovies(it) }
            shows.chunked(2000).forEach { catalogDao.insertShows(it) }
        }
        "${movies.size} films · ${shows.size} séries"
    }

    private suspend fun autoCatalog(id: Long): String {
        if (catalogDao.movieCount(id) + catalogDao.showCount(id) == 0) return ""
        return try { " · " + loadCatalog(id) } catch (e: Exception) { " · catalogue : ${e.message}" }
    }

    private val infoGate = Semaphore(3)
    private val infoFailed = ConcurrentHashMap.newKeySet<Long>()

    /** Charge la description, le casting et la note détaillée d'un film (get_vod_info), puis la met en cache. */
    suspend fun loadMovieInfo(m: Movie) {
        if (m.infoLoaded || m.id in infoFailed) return
        infoGate.withPermit {
            withContext(Dispatchers.IO) {
                try {
                    val p = plDao.get(m.playlistId) ?: return@withContext
                    val root = JSONObject(text("${xApi(p)}&action=get_vod_info&vod_id=${m.streamId}"))
                    val info = root.optJSONObject("info") ?: JSONObject()
                    val plot = info.str("plot").ifEmpty { info.str("description") }
                    catalogDao.setMovieInfo(
                        m.id, plot.ifEmpty { "Aucune description disponible." },
                        info.str("genre"), info.str("cast").ifEmpty { info.str("actors") }, info.str("director"),
                        firstStr(info, "backdrop_path"), info.str("duration"),
                        info.str("releasedate").ifEmpty { info.str("releaseDate") }.take(4), rating10(info)
                    )
                } catch (e: Exception) { infoFailed.add(m.id) }
            }
        }
    }

    /** Épisodes d'une série (get_series_info) ; met aussi à jour sa description. */
    suspend fun loadEpisodes(s: Show): List<Episode> = withContext(Dispatchers.IO) {
        val p = plDao.get(s.playlistId) ?: throw IOException("Playlist introuvable")
        val root = JSONObject(text("${xApi(p)}&action=get_series_info&series_id=${s.seriesId}"))
        val info = root.optJSONObject("info") ?: JSONObject()
        catalogDao.setShowInfo(
            s.id, info.str("plot"), info.str("genre"), info.str("cast"), info.str("director"), firstStr(info, "backdrop_path")
        )
        val base = xBase(p.source)
        val out = ArrayList<Episode>()
        fun add(season: Int, o: JSONObject) {
            val inf = o.optJSONObject("info") ?: JSONObject()
            val n = o.str("episode_num").toIntOrNull() ?: (out.size + 1)
            out += Episode(
                season = o.str("season").toIntOrNull() ?: season, number = n,
                title = o.str("title").ifEmpty { "Épisode $n" },
                url = "$base/series/${enc(p.user)}/${enc(p.pass)}/${o.str("id")}.${o.str("container_extension").ifEmpty { "mp4" }}",
                image = inf.str("movie_image"), plot = inf.str("plot"), duration = inf.str("duration"), rating = rating10(inf)
            )
        }
        when (val eps = root.opt("episodes")) {
            is JSONObject -> eps.keys().asSequence().sortedBy { it.toIntOrNull() ?: 0 }.forEach { k ->
                val arr = eps.optJSONArray(k) ?: return@forEach
                for (i in 0 until arr.length()) add(k.toIntOrNull() ?: 1, arr.getJSONObject(i))
            }
            is JSONArray -> for (si in 0 until eps.length()) {
                val arr = eps.optJSONArray(si) ?: continue
                for (i in 0 until arr.length()) add(si + 1, arr.getJSONObject(i))
            }
        }
        out
    }

    private suspend fun saveChannels(playlistId: Long, list: List<Channel>) {
        val favs = dao.favoriteUrls(playlistId).toSet()
        db.withTransaction {
            dao.deleteForPlaylist(playlistId)
            list.chunked(2000).forEach { chunk ->
                dao.insertAll(chunk.map { it.copy(playlistId = playlistId, favorite = it.url in favs) })
            }
        }
    }
}
