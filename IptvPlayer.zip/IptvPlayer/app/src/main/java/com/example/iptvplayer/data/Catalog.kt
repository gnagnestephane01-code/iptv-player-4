package com.example.iptvplayer.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Film Xtream (VOD). rating sur 10. La description arrive à la demande (get_vod_info). */
@Entity(tableName = "movies", indices = [Index("playlistId")])
data class Movie(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val streamId: String,
    val name: String,
    val poster: String = "",
    val rating: Float = 0f,
    val category: String = "",
    val ext: String = "mp4",
    val year: String = "",
    val plot: String = "",
    val genre: String = "",
    val actors: String = "",
    val director: String = "",
    val backdrop: String = "",
    val duration: String = "",
    val added: Long = 0,
    val infoLoaded: Boolean = false
)

@Entity(tableName = "shows", indices = [Index("playlistId")])
data class Show(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val playlistId: Long,
    val seriesId: String,
    val name: String,
    val cover: String = "",
    val rating: Float = 0f,
    val category: String = "",
    val plot: String = "",
    val genre: String = "",
    val year: String = "",
    val actors: String = "",
    val director: String = "",
    val backdrop: String = "",
    val added: Long = 0
)

/** Épisode : chargé à l'ouverture d'une série (non stocké). */
data class Episode(
    val season: Int, val number: Int, val title: String, val url: String,
    val image: String, val plot: String, val duration: String, val rating: Float
)

@Entity(tableName = "scheduled_recordings")
data class ScheduledRecording(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val channelName: String,
    val url: String,
    val startAt: Long,
    val endAt: Long
)

/** Position de lecture d'un film ou d'un épisode (clé = URL du flux). Une ligne `finished` = déjà vu. */
@Entity(tableName = "watch_progress")
data class WatchProgress(
    @PrimaryKey val url: String,
    /** "movie" ou "episode" */
    val kind: String,
    /** Titre du film, ou nom de la série. */
    val title: String,
    /** "" pour un film, "S2 E5" pour un épisode. */
    val subtitle: String,
    val image: String,
    /** Id du film, ou id de la série. */
    val refId: Long,
    val season: Int,
    val episode: Int,
    val category: String,
    val positionMs: Long,
    val durationMs: Long,
    val updatedAt: Long,
    val finished: Boolean
) {
    fun fraction(): Float = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
}
