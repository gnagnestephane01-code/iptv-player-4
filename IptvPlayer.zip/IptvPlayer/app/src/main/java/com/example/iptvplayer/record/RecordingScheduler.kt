package com.example.iptvplayer.record

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.iptvplayer.data.AppDatabase
import com.example.iptvplayer.data.ScheduledRecording
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Programme les enregistrements à une heure précise avec AlarmManager (survit au redémarrage de l'appareil). */
object RecordingScheduler {
    const val ACTION_ALARM = "com.example.iptvplayer.REC_ALARM"

    private fun alarmManager(ctx: Context) = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun pending(ctx: Context, id: Long): PendingIntent = PendingIntent.getBroadcast(
        ctx, id.toInt(),
        Intent(ctx, RecordingAlarmReceiver::class.java).setAction(ACTION_ALARM).putExtra("id", id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun canExact(ctx: Context): Boolean = Build.VERSION.SDK_INT < 31 || alarmManager(ctx).canScheduleExactAlarms()

    /** Retourne true si l'alarme est exacte, false si l'heure sera approximative (permission refusée). */
    fun schedule(ctx: Context, rec: ScheduledRecording): Boolean {
        val am = alarmManager(ctx)
        val pi = pending(ctx, rec.id)
        if (canExact(ctx)) {
            try {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, rec.startAt, pi)
                return true
            } catch (e: SecurityException) { /* retombe sur l'alarme approximative */ }
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, rec.startAt, pi)
        return false
    }

    fun cancel(ctx: Context, id: Long) = alarmManager(ctx).cancel(pending(ctx, id))

    /** Ouvre l'écran système « Alarmes et rappels » (Android 12+). */
    fun requestExactPermission(ctx: Context) {
        if (Build.VERSION.SDK_INT < 31) return
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) { /* écran indisponible (certaines TV) */ }
    }

    /** Recrée les alarmes (démarrage de l'app, redémarrage de l'appareil) et purge les programmations terminées. */
    suspend fun rescheduleAll(ctx: Context) {
        val dao = AppDatabase.get(ctx).scheduledDao()
        val now = System.currentTimeMillis()
        for (r in dao.all()) {
            if (r.endAt <= now) { cancel(ctx, r.id); dao.delete(r.id) } else schedule(ctx, r)
        }
    }
}

class RecordingAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                when (intent.action) {
                    RecordingScheduler.ACTION_ALARM -> fire(ctx, intent.getLongExtra("id", -1L))
                    else -> RecordingScheduler.rescheduleAll(ctx)   // BOOT_COMPLETED, MY_PACKAGE_REPLACED
                }
            } finally {
                pending.finish()
            }
        }
    }

    private suspend fun fire(ctx: Context, id: Long) {
        val dao = AppDatabase.get(ctx).scheduledDao()
        val rec = dao.get(id) ?: return
        dao.delete(id)
        val remainingSec = (rec.endAt - System.currentTimeMillis()) / 1000
        if (remainingSec <= 0) return    // créneau déjà passé (appareil éteint)
        val i = Intent(ctx, RecordingService::class.java)
            .setAction(RecordingService.ACTION_START)
            .putExtra("url", rec.url).putExtra("name", rec.channelName).putExtra("duration", remainingSec)
        try {
            ContextCompat.startForegroundService(ctx, i)
        } catch (e: Exception) {
            // Android 12+ : démarrage refusé sans alarme exacte autorisée
        }
    }
}
