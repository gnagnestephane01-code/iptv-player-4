package com.example.iptvplayer.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.iptvplayer.data.Channel
import com.example.iptvplayer.data.Episode
import com.example.iptvplayer.data.Movie
import com.example.iptvplayer.data.ScheduledRecording
import com.example.iptvplayer.data.Show
import com.example.iptvplayer.data.WatchProgress
import com.example.iptvplayer.record.RecordingScheduler
import com.example.iptvplayer.data.Parental
import com.example.iptvplayer.data.ParentalState
import com.example.iptvplayer.data.Playlist
import com.example.iptvplayer.data.Programme
import com.example.iptvplayer.data.Replay
import com.example.iptvplayer.data.Repository
import com.example.iptvplayer.record.Recorder
import com.example.iptvplayer.record.RecordingService
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withPermit

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val appCtx: Application = app
    private val repo = Repository(app)
    val prefs = repo.prefs

    val query = MutableStateFlow("")
    val group = MutableStateFlow("")
    val favOnly = MutableStateFlow(false)
    /** 0 = toutes les playlists */
    val playlistFilter = MutableStateFlow(0L)
    val loading = MutableStateFlow(false)
    val message = MutableStateFlow<String?>(null)
    val backgroundPlay = MutableStateFlow(prefs.backgroundPlay)

    init {
        viewModelScope.launch { Recorder.messages.collect { message.value = it } }
    }

    // ----- replay / enregistrement -----
    val activeRecordings = Recorder.active

    fun replayUrl(c: Channel, p: Programme): String? =
        Replay.url(c, p, playlists.value.firstOrNull { it.id == c.playlistId })

    fun canReplay(c: Channel, p: Programme): Boolean = Replay.canReplay(c, p, clock.value)

    /** durationSec = 0 : jusqu'à l'arrêt manuel. */
    fun startRecording(c: Channel, durationSec: Long) {
        val i = Intent(appCtx, RecordingService::class.java)
            .setAction(RecordingService.ACTION_START)
            .putExtra("url", c.url).putExtra("name", c.name).putExtra("duration", durationSec)
        ContextCompat.startForegroundService(appCtx, i)
        message.value = "Enregistrement démarré : ${c.name}"
    }

    fun stopRecording(id: Long) = Recorder.stop(id)

    // ----- parental -----
    private val _parental = MutableStateFlow(
        ParentalState(prefs.pinHash.isNotEmpty(), prefs.autoAdult, prefs.lockedGroups, unlocked = false)
    )
    val parental: StateFlow<ParentalState> = _parental.asStateFlow()
    private var fails = 0
    private var blockedUntil = 0L

    /** Retourne null si le PIN est bon, sinon le message d'erreur. */
    fun tryUnlock(pin: String): String? {
        val now = System.currentTimeMillis()
        if (now < blockedUntil) return "Trop d'essais. Réessaie dans ${(blockedUntil - now) / 1000 + 1} s"
        if (Parental.hash(prefs.pinSalt, pin) == prefs.pinHash) {
            fails = 0
            _parental.update { it.copy(unlocked = true) }
            return null
        }
        fails++
        if (fails >= 5) { fails = 0; blockedUntil = now + 60_000; return "Trop d'essais. Réessaie dans 1 min" }
        return "Code incorrect"
    }

    fun setPin(pin: String): Boolean {
        if (pin.length != 4 || !pin.all(Char::isDigit)) return false
        val salt = Parental.newSalt()
        prefs.pinSalt = salt
        prefs.pinHash = Parental.hash(salt, pin)
        _parental.update { it.copy(hasPin = true, unlocked = true) }
        return true
    }

    fun removePin() {
        prefs.pinHash = ""; prefs.pinSalt = ""
        _parental.update { it.copy(hasPin = false, unlocked = false) }
    }

    fun lock() { if (_parental.value.hasPin) _parental.update { it.copy(unlocked = false) } }

    fun setAutoAdult(v: Boolean) { prefs.autoAdult = v; _parental.update { it.copy(autoAdult = v) } }

    fun toggleGroupLock(g: String) {
        val s = _parental.value.lockedGroups.toMutableSet()
        if (!s.add(g)) s.remove(g)
        prefs.lockedGroups = s
        _parental.update { it.copy(lockedGroups = s) }
    }

    fun setBackgroundPlay(v: Boolean) { prefs.backgroundPlay = v; backgroundPlay.value = v }

    val autoNext = MutableStateFlow(prefs.autoNext)
    fun setAutoNext(v: Boolean) { prefs.autoNext = v; autoNext.value = v }

    // ----- données -----
    val clock: StateFlow<Long> = flow {
        while (true) { emit(System.currentTimeMillis()); delay(30_000) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, System.currentTimeMillis())

    val playlists: StateFlow<List<Playlist>> =
        repo.playlists.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Toutes les catégories (sans filtre parental) pour l'écran de réglage. */
    val allGroups: StateFlow<List<String>> =
        repo.groups(0).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val groups: StateFlow<List<String>> =
        combine(playlistFilter.flatMapLatest { repo.groups(it) }, parental) { list, p ->
            if (Parental.restricted(p)) list.filterNot { Parental.isGroupLocked(it, p) } else list
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private data class Filter(val q: String, val g: String, val f: Boolean, val p: Long)

    val channels: StateFlow<List<Channel>> =
        combine(query, group, favOnly, playlistFilter) { q, g, f, p -> Filter(q, g, f, p) }
            .flatMapLatest { repo.channels(it.q, it.g, it.f, it.p) }
            .combine(parental) { list, p ->
                if (Parental.restricted(p)) list.filterNot { Parental.isChannelLocked(it, p) } else list
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val nowPlaying: StateFlow<Map<String, Programme>> =
        clock.flatMapLatest { repo.current(it) }
            .map { list -> list.associateBy { it.channelKey } }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    fun schedule(epgKey: String): Flow<List<Programme>> =
        if (epgKey.isEmpty()) flowOf(emptyList()) else repo.schedule(epgKey)

    fun selectPlaylist(id: Long) { playlistFilter.value = id; group.value = "" }

    private fun task(block: suspend () -> String) {
        viewModelScope.launch {
            loading.value = true
            message.value = try {
                block()
            } catch (e: Exception) {
                "Erreur : ${e.message ?: e.javaClass.simpleName}"
            }
            loading.value = false
        }
    }

    fun addM3uUrl(name: String, url: String) {
        val u = url.trim()
        if (!u.startsWith("http")) { message.value = "URL invalide (http:// ou https://)"; return }
        task { repo.addM3uUrl(name.trim(), u) }
    }

    fun addM3uFile(name: String, uri: Uri) = task { repo.addM3uFile(name.trim(), uri) }

    fun addXtream(name: String, server: String, user: String, pass: String) {
        if (server.isBlank() || user.isBlank() || pass.isBlank()) {
            message.value = "Renseigne le serveur, l'identifiant et le mot de passe"; return
        }
        task { repo.addXtream(name.trim(), server, user, pass) }
    }

    fun refreshPlaylist(id: Long) = task { repo.refreshPlaylist(id) }
    fun refreshAll() = task { repo.refreshAll() }

    fun updateEpg(playlistId: Long, url: String) {
        if (!url.trim().startsWith("http")) { message.value = "URL du guide invalide"; return }
        task { "Guide : ${repo.updateEpg(playlistId, url.trim())} programmes" }
    }

    fun deletePlaylist(id: Long) {
        if (playlistFilter.value == id) selectPlaylist(0)
        viewModelScope.launch { repo.deletePlaylist(id); message.value = "Playlist supprimée" }
    }

    fun toggleFavorite(c: Channel) = viewModelScope.launch { repo.setFavorite(c.id, !c.favorite) }

    // ----- enregistrements programmés -----
    val scheduled: StateFlow<List<ScheduledRecording>> =
        repo.scheduled.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private var askedExact = false

    init { viewModelScope.launch { RecordingScheduler.rescheduleAll(appCtx) } }

    fun scheduleRecording(c: Channel, startAt: Long, endAt: Long) {
        val now = System.currentTimeMillis()
        if (endAt <= now || endAt <= startAt) { message.value = "Heure invalide"; return }
        if (scheduled.value.any { it.url == c.url && kotlin.math.abs(it.startAt - startAt) < 60_000 }) {
            message.value = "Déjà programmé"; return
        }
        viewModelScope.launch {
            val rec = ScheduledRecording(channelName = c.name, url = c.url, startAt = startAt, endAt = endAt)
            val id = repo.addScheduled(rec)
            val exact = RecordingScheduler.schedule(appCtx, rec.copy(id = id))
            val whenTxt = java.text.SimpleDateFormat("EEE d MMM HH:mm", java.util.Locale.getDefault()).format(java.util.Date(startAt))
            message.value = "Programmé : ${c.name}, $whenTxt" + if (exact) "" else " (heure approximative)"
            if (!exact && !askedExact) { askedExact = true; RecordingScheduler.requestExactPermission(appCtx) }
        }
    }

    /** Programme (ou annule) l'enregistrement d'un programme du guide, avec 1 min avant et 3 min après. */
    fun toggleProgrammeRecording(c: Channel, p: Programme) {
        val start = p.start - 60_000
        val existing = scheduled.value.firstOrNull { it.url == c.url && kotlin.math.abs(it.startAt - start) < 120_000 }
        if (existing != null) cancelScheduled(existing)
        else scheduleRecording(c, maxOf(start, System.currentTimeMillis() + 5_000), p.stop + 180_000)
    }

    fun cancelScheduled(r: ScheduledRecording) {
        RecordingScheduler.cancel(appCtx, r.id)
        viewModelScope.launch { repo.removeScheduled(r.id); message.value = "Programmation annulée" }
    }

    // ----- films & séries -----
    val catQuery = MutableStateFlow("")
    val movieCat = MutableStateFlow("")
    val showCat = MutableStateFlow("")
    val catalogTotal: StateFlow<Int> = repo.catalogTotal.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val hasXtream: StateFlow<Boolean> =
        playlists.map { l -> l.any { it.type == "xtream" } }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    private data class CatFilter(val q: String, val c: String, val p: Long)

    val movies: StateFlow<List<Movie>> =
        combine(catQuery, movieCat, playlistFilter) { q, c, p -> CatFilter(q, c, p) }
            .flatMapLatest { repo.movies(it.q, it.c, it.p) }
            .combine(parental) { list, p ->
                if (Parental.restricted(p)) list.filterNot { Parental.isTextLocked(it.category, it.name, p) } else list
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val shows: StateFlow<List<Show>> =
        combine(catQuery, showCat, playlistFilter) { q, c, p -> CatFilter(q, c, p) }
            .flatMapLatest { repo.shows(it.q, it.c, it.p) }
            .combine(parental) { list, p ->
                if (Parental.restricted(p)) list.filterNot { Parental.isTextLocked(it.category, it.name, p) } else list
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val movieCategories: StateFlow<List<String>> =
        playlistFilter.flatMapLatest { repo.movieCategories(it) }
            .combine(parental) { list, p -> if (Parental.restricted(p)) list.filterNot { Parental.isGroupLocked(it, p) } else list }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val showCategories: StateFlow<List<String>> =
        playlistFilter.flatMapLatest { repo.showCategories(it) }
            .combine(parental) { list, p -> if (Parental.restricted(p)) list.filterNot { Parental.isGroupLocked(it, p) } else list }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun observeMovie(id: Long) = repo.observeMovie(id)
    fun observeShow(id: Long) = repo.observeShow(id)

    fun loadCatalog() = task {
        val targets = playlists.value.filter { it.type == "xtream" }
        if (targets.isEmpty()) throw IllegalStateException("Ajoute d'abord une source Xtream Codes")
        targets.map { p ->
            try { "${p.name} : ${repo.loadCatalog(p.id)}" } catch (e: Exception) { "${p.name} : ${e.message}" }
        }.joinToString(" | ")
    }

    private val infoGate = kotlinx.coroutines.sync.Semaphore(3)
    private val infoRequested = HashSet<Long>()

    fun ensureMovieInfo(m: Movie) {
        if (m.infoLoaded || !infoRequested.add(m.id)) return
        viewModelScope.launch {
            infoGate.withPermit {
                try { repo.loadMovieInfo(m) } catch (e: Exception) { infoRequested.remove(m.id) }
            }
        }
    }

    fun movieUrl(m: Movie): String? =
        playlists.value.firstOrNull { it.id == m.playlistId }?.let { repo.movieUrl(it, m) }

    // ----- reprise de lecture -----
    /** Toutes les positions mémorisées, par URL (barres de progression, « vu »). */
    val watchProgress: StateFlow<Map<String, WatchProgress>> =
        repo.progress.map { l -> l.associateBy { it.url } }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    /** « Continuer à regarder » : non terminés, du plus récent au plus ancien, un seul épisode par série. */
    val continueWatching: StateFlow<List<WatchProgress>> =
        combine(repo.progress, parental) { list, p ->
            list.filter { !it.finished && it.positionMs > 10_000 }
                .filter { !Parental.restricted(p) || !Parental.isTextLocked(it.category, it.title, p) }
                .sortedByDescending { it.updatedAt }
                .distinctBy { if (it.kind == "episode") "e${it.refId}" else it.url }
                .take(30)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Appelé toutes les 5 s par le lecteur, en quittant, et en fin de lecture. */
    fun saveProgress(url: String, r: ResumeInfo, posMs: Long, durMs: Long) {
        if (durMs <= 0) return
        val finished = posMs >= durMs * 0.95 || durMs - posMs < 45_000
        if (!finished && posMs < 10_000) return    // démarrage : on garde l'ancienne position
        viewModelScope.launch {
            repo.saveProgress(
                WatchProgress(
                    url, r.kind, r.baseTitle, r.subtitle, r.image, r.refId, r.season, r.episode, r.category,
                    if (finished) 0L else posMs, durMs, System.currentTimeMillis(), finished
                )
            )
        }
    }

    fun removeProgress(url: String) { viewModelScope.launch { repo.removeProgress(url) } }

    /** Épisode qui suit [r] (même saison, sinon début de la saison suivante). Charge la liste si besoin. */
    suspend fun nextEpisodeAfter(r: ResumeInfo): NextEpisode? {
        if (r.kind != "episode" || r.refId == 0L) return null
        val cached = episodes.value[r.refId]
        val eps: List<Episode> = if (cached != null) cached else {
            val show = repo.observeShow(r.refId).first() ?: return null
            val loaded = try { repo.loadEpisodes(show) } catch (e: Exception) { return null }
            episodes.update { it + (show.id to loaded) }
            loaded
        }
        val next = eps.sortedWith(compareBy({ it.season }, { it.number }))
            .firstOrNull { it.season > r.season || (it.season == r.season && it.number > r.episode) } ?: return null
        val label = "S${next.season} E${next.number}"
        val img = next.image.ifEmpty { r.image }
        return NextEpisode(
            PlaySource.Vod("${r.baseTitle} · $label", next.url,
                ResumeInfo("episode", r.baseTitle, label, img, r.refId, next.season, next.number, r.category, 0L)),
            label, next.title.ifBlank { "Épisode ${next.number}" }, img
        )
    }

    val episodes = MutableStateFlow<Map<Long, List<Episode>>>(emptyMap())
    val episodesLoading = MutableStateFlow(false)

    fun loadEpisodes(s: Show) {
        if (episodes.value.containsKey(s.id)) return
        viewModelScope.launch {
            episodesLoading.value = true
            try { episodes.update { it + (s.id to repo.loadEpisodes(s)) } }
            catch (e: Exception) { message.value = "Épisodes : ${e.message}" }
            episodesLoading.value = false
        }
    }
}
