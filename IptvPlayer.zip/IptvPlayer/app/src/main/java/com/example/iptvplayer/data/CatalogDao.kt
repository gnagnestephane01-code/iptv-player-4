package com.example.iptvplayer.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CatalogDao {
    // ----- films -----
    @Query(
        "SELECT * FROM movies WHERE (:pl = 0 OR playlistId = :pl) AND (:cat = '' OR category = :cat) " +
            "AND name LIKE '%' || :q || '%' ORDER BY added DESC, id DESC LIMIT 600"
    )
    fun movies(q: String, cat: String, pl: Long): Flow<List<Movie>>

    @Query("SELECT DISTINCT category FROM movies WHERE category != '' AND (:pl = 0 OR playlistId = :pl) ORDER BY category")
    fun movieCategories(pl: Long): Flow<List<String>>

    @Query("SELECT * FROM movies WHERE id = :id")
    fun observeMovie(id: Long): Flow<Movie?>

    @Query("SELECT COUNT(*) FROM movies WHERE playlistId = :pl")
    suspend fun movieCount(pl: Long): Int

    @Query("SELECT * FROM movies WHERE playlistId = :pl AND infoLoaded = 1")
    suspend fun loadedMovies(pl: Long): List<Movie>

    @Query("DELETE FROM movies WHERE playlistId = :pl")
    suspend fun deleteMovies(pl: Long)

    @Insert
    suspend fun insertMovies(list: List<Movie>)

    @Query(
        "UPDATE movies SET plot = :plot, genre = :genre, actors = :actors, director = :director, backdrop = :backdrop, " +
            "duration = :duration, year = CASE WHEN :year != '' THEN :year ELSE year END, " +
            "rating = CASE WHEN :rating > 0 THEN :rating ELSE rating END, infoLoaded = 1 WHERE id = :id"
    )
    suspend fun setMovieInfo(
        id: Long, plot: String, genre: String, actors: String, director: String,
        backdrop: String, duration: String, year: String, rating: Float
    )

    // ----- séries -----
    @Query(
        "SELECT * FROM shows WHERE (:pl = 0 OR playlistId = :pl) AND (:cat = '' OR category = :cat) " +
            "AND name LIKE '%' || :q || '%' ORDER BY added DESC, id DESC LIMIT 600"
    )
    fun shows(q: String, cat: String, pl: Long): Flow<List<Show>>

    @Query("SELECT DISTINCT category FROM shows WHERE category != '' AND (:pl = 0 OR playlistId = :pl) ORDER BY category")
    fun showCategories(pl: Long): Flow<List<String>>

    @Query("SELECT * FROM shows WHERE id = :id")
    fun observeShow(id: Long): Flow<Show?>

    @Query("SELECT COUNT(*) FROM shows WHERE playlistId = :pl")
    suspend fun showCount(pl: Long): Int

    @Query("DELETE FROM shows WHERE playlistId = :pl")
    suspend fun deleteShows(pl: Long)

    @Insert
    suspend fun insertShows(list: List<Show>)

    @Query(
        "UPDATE shows SET plot = CASE WHEN :plot != '' THEN :plot ELSE plot END, " +
            "genre = CASE WHEN :genre != '' THEN :genre ELSE genre END, " +
            "actors = CASE WHEN :actors != '' THEN :actors ELSE actors END, " +
            "director = CASE WHEN :director != '' THEN :director ELSE director END, " +
            "backdrop = CASE WHEN :backdrop != '' THEN :backdrop ELSE backdrop END WHERE id = :id"
    )
    suspend fun setShowInfo(id: Long, plot: String, genre: String, actors: String, director: String, backdrop: String)

    @Query("SELECT (SELECT COUNT(*) FROM movies) + (SELECT COUNT(*) FROM shows)")
    fun total(): Flow<Int>
}

@Dao
interface ScheduledDao {
    @Query("SELECT * FROM scheduled_recordings ORDER BY startAt")
    fun observe(): Flow<List<ScheduledRecording>>

    @Query("SELECT * FROM scheduled_recordings ORDER BY startAt")
    suspend fun all(): List<ScheduledRecording>

    @Query("SELECT * FROM scheduled_recordings WHERE id = :id")
    suspend fun get(id: Long): ScheduledRecording?

    @Insert
    suspend fun insert(r: ScheduledRecording): Long

    @Query("DELETE FROM scheduled_recordings WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface ProgressDao {
    @Query("SELECT * FROM watch_progress ORDER BY updatedAt DESC LIMIT 1000")
    fun observeAll(): Flow<List<WatchProgress>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(p: WatchProgress)

    @Query("DELETE FROM watch_progress WHERE url = :url")
    suspend fun delete(url: String)
}
