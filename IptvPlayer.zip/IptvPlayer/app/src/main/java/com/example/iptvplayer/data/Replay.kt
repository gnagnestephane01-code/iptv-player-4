package com.example.iptvplayer.data

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Construit l'URL de replay (catch-up) d'un programme passé. */
object Replay {
    fun canReplay(c: Channel, p: Programme, now: Long): Boolean =
        c.catchupDays > 0 && c.catchupType.isNotEmpty() &&
            p.start <= now && p.start >= now - c.catchupDays * 86_400_000L

    fun url(c: Channel, p: Programme, playlist: Playlist?): String? {
        val now = System.currentTimeMillis()
        if (!canReplay(c, p, now)) return null

        val isXc = playlist?.type == "xtream"
        val tzId = playlist?.tz.orEmpty()
        val zone = when {
            isXc && tzId.isNotEmpty() -> TimeZone.getTimeZone(tzId)
            isXc -> TimeZone.getDefault()
            else -> TimeZone.getTimeZone("UTC")
        }
        val startSec = p.start / 1000
        val endSec = p.stop / 1000
        val dur = (p.stop - p.start) / 1000

        fun fmt(pattern: String): String =
            SimpleDateFormat(pattern, Locale.US).apply { timeZone = zone }.format(Date(p.start))

        fun fill(t: String): String = t
            .replace("\${start}", "$startSec").replace("\${timestamp}", "$startSec").replace("{utc}", "$startSec")
            .replace("\${end}", "$endSec").replace("{utcend}", "$endSec")
            .replace("{lutc}", "${now / 1000}")
            .replace("\${duration}", "$dur").replace("{duration}", "$dur")
            .replace("{dmin}", "${maxOf(dur / 60, 1)}")
            .replace("{Y}", fmt("yyyy")).replace("{m}", fmt("MM")).replace("{d}", fmt("dd"))
            .replace("{H}", fmt("HH")).replace("{M}", fmt("mm")).replace("{S}", fmt("ss"))

        return when (c.catchupType) {
            "default" -> c.catchupSource.takeIf { it.isNotEmpty() }?.let { fill(it) }
            "append" -> c.url + fill(c.catchupSource)
            "shift" -> c.url + (if ('?' in c.url) "&" else "?") + fill("utc={utc}&lutc={lutc}")
            else -> null
        }
    }
}
