package com.example.iptvplayer.record

import android.content.Context
import android.os.Environment
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import java.io.BufferedInputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

data class ActiveRecording(
    val id: Long, val channel: String, val fileName: String,
    val startedAt: Long, val endAt: Long, val bytes: Long
)

/** État partagé des enregistrements + copie d'un flux (TS direct ou HLS) vers un fichier .ts. */
object Recorder {
    val active = MutableStateFlow<Map<Long, ActiveRecording>>(emptyMap())
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    internal val jobs = ConcurrentHashMap<Long, Job>()

    fun stop(id: Long) { jobs[id]?.cancel() }
    fun stopAll() { jobs.values.forEach { it.cancel() } }

    fun dir(context: Context): File =
        File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: context.filesDir, "IPTV").apply { mkdirs() }

    fun files(context: Context): List<File> =
        dir(context).listFiles { f -> f.isFile && f.length() > 0 }?.sortedByDescending { it.lastModified() } ?: emptyList()

    // ---------- réseau ----------
    private fun open(url: String): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) IPTVPlayer/1.0")
        if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
        return conn
    }

    private fun fetchText(url: String): String {
        val conn = open(url)
        try { return conn.inputStream.bufferedReader().use { it.readText() } } finally { conn.disconnect() }
    }

    private fun resolve(base: String, rel: String): String = URL(URL(base), rel).toString()

    private suspend fun alive(endAt: Long) =
        currentCoroutineContext().isActive && System.currentTimeMillis() < endAt

    // ---------- enregistrement ----------
    /** Écrit le flux dans [out] jusqu'à [endAt] (epoch ms) ou jusqu'à l'annulation. */
    suspend fun record(url: String, out: OutputStream, endAt: Long, onBytes: (Long) -> Unit) {
        var total = 0L
        val add: (Int) -> Unit = { n -> total += n; onBytes(total) }

        val conn = open(url)
        try {
            val input = BufferedInputStream(conn.inputStream, 64 * 1024)
            input.mark(16)
            val head = ByteArray(7)
            val n = input.read(head)
            input.reset()
            if (n == 7 && String(head, Charsets.US_ASCII) == "#EXTM3U") {
                val text = input.bufferedReader().readText()
                conn.disconnect()
                recordHls(url, text, out, endAt, add)
            } else {
                copy(input, out, endAt, add)
            }
        } finally {
            conn.disconnect()
        }
    }

    private suspend fun copy(input: InputStream, out: OutputStream, endAt: Long, add: (Int) -> Unit) {
        val buf = ByteArray(64 * 1024)
        while (alive(endAt)) {
            val n = input.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            add(n)
        }
    }

    private suspend fun recordHls(url: String, firstText: String, out: OutputStream, endAt: Long, add: (Int) -> Unit) {
        var playlistUrl = url
        var text = firstText
        if (text.contains("#EXT-X-STREAM-INF")) {
            playlistUrl = bestVariant(url, text) ?: throw IOException("Aucune variante trouvée")
            text = fetchText(playlistUrl)
        }
        val seen = LinkedHashSet<String>()
        while (alive(endAt)) {
            if (text.contains("#EXT-X-KEY") && !text.contains("METHOD=NONE")) throw IOException("Flux chiffré : enregistrement impossible")
            if (text.contains("#EXT-X-MAP")) throw IOException("Segments fMP4 non pris en charge")

            val segs = text.lineSequence().map { it.trim() }
                .filter { it.isNotEmpty() && !it.startsWith("#") }
                .map { resolve(playlistUrl, it) }.toList()
            var fresh = 0
            for (s in segs) {
                if (!alive(endAt)) break
                if (seen.add(s)) {
                    fresh++
                    try { download(s, out, add) } catch (e: IOException) { /* segment manquant : on continue */ }
                }
            }
            while (seen.size > 2000) {
                val iter = seen.iterator(); iter.next(); iter.remove()
            }
            if (text.contains("#EXT-X-ENDLIST")) break
            val target = Regex("#EXT-X-TARGETDURATION:(\\d+)").find(text)?.groupValues?.get(1)?.toLongOrNull() ?: 6L
            delay(if (fresh == 0) 1000L else target * 500L)
            text = fetchText(playlistUrl)
        }
    }

    private fun download(url: String, out: OutputStream, add: (Int) -> Unit) {
        val conn = open(url)
        try {
            conn.inputStream.use { input ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    add(n)
                }
            }
        } finally { conn.disconnect() }
    }

    private fun bestVariant(base: String, text: String): String? {
        var best: String? = null
        var bestBw = -1L
        var pendingBw = -1L
        for (raw in text.lines()) {
            val l = raw.trim()
            if (l.startsWith("#EXT-X-STREAM-INF")) {
                pendingBw = Regex("BANDWIDTH=(\\d+)").find(l)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
            } else if (l.isNotEmpty() && !l.startsWith("#") && pendingBw >= 0) {
                if (pendingBw > bestBw) { bestBw = pendingBw; best = resolve(base, l) }
                pendingBw = -1
            }
        }
        return best
    }
}
