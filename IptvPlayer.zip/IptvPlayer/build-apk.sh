#!/usr/bin/env bash
# Compile l'APK debug (téléphone + Android TV). Prérequis : JDK 17+, SDK Android (voir LISEZ-MOI-BUILD.md).
set -euo pipefail
cd "$(dirname "$0")"

SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/Android/Sdk}}"
[ -d "$SDK" ] || { echo "SDK Android introuvable. Définis ANDROID_HOME (voir LISEZ-MOI-BUILD.md)."; exit 1; }
echo "sdk.dir=$SDK" > local.properties

if [ ! -x ./gradlew ]; then
  command -v gradle >/dev/null || { echo "Gradle 8.7+ requis pour générer le wrapper (ou ouvre le dossier dans Android Studio)."; exit 1; }
  gradle wrapper --gradle-version 8.7
fi

./gradlew --no-daemon :app:assembleDebug
cp app/build/outputs/apk/debug/app-debug.apk IptvPlayer-debug.apk
echo "APK prêt : $(pwd)/IptvPlayer-debug.apk"
