# Compiler l'APK (téléphone + Android TV)

Le même APK s'installe sur le téléphone et sur la TV (le lanceur Android TV est déclaré dans le manifeste).

## Option 1 — Android Studio (la plus simple)
1. Installe Android Studio (version récente), ouvre le dossier `IptvPlayer`.
2. Laisse la synchronisation Gradle se terminer (il télécharge tout seul le SDK 34 et les dépendances).
3. Menu **Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)**.
4. L'APK est dans `app/build/outputs/apk/debug/app-debug.apk`.

## Option 2 — Ligne de commande (Linux / macOS / WSL)
Prérequis : JDK 17, Gradle 8.7+ (une seule fois, pour générer `gradlew`) et le SDK Android :

    sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"
    export ANDROID_HOME=$HOME/Android/Sdk
    ./build-apk.sh

Résultat : `IptvPlayer-debug.apk` à la racine.

## Option 3 — Sans rien installer (GitHub Actions)
1. Crée un dépôt GitHub (privé) et envoie-y le contenu du dossier.
2. Onglet **Actions ▸ Build APK ▸ Run workflow**.
3. À la fin, télécharge l'artefact **IptvPlayer-debug-apk**.

## Installer
**Téléphone** : copie l'APK, ouvre-le, autorise « Sources inconnues » pour l'app qui l'ouvre. Ou en USB : `adb install -r IptvPlayer-debug.apk`.

**Android TV** :
- `adb connect IP_DE_LA_TV:5555` (Options développeur ▸ Débogage réseau activé), puis `adb install -r IptvPlayer-debug.apk`
- ou envoie l'APK par clé USB / avec l'app « Send Files to TV », puis ouvre-le avec un gestionnaire de fichiers.
L'app apparaît dans la liste des applications de la TV (bannière incluse).

## Notes
- L'APK « debug » est signé avec la clé de debug générée automatiquement : parfait pour un usage perso. Pour le Play Store, il faut un APK/AAB « release » signé avec ta propre clé.
- Chromecast : le bouton n'apparaît que sur téléphone avec Google Play Services.
